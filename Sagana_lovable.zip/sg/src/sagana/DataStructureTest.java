package sagana;

import sagana.ds.*;
import sagana.model.*;
import sagana.service.*;
import java.time.LocalDateTime;
import java.util.List;

/** Verifies the custom data structures and algorithms. Run: java -cp out sagana.DataStructureTest */
public class DataStructureTest {
    private static int passed = 0, failed = 0;

    private static void check(String name, boolean ok) {
        if (ok) passed++; else failed++;
        System.out.println((ok ? "PASS " : "FAIL ") + name);
    }

    public static void main(String[] args) {
        ResizableArray<Integer> arr = new ResizableArray<>();
        for (int i = 0; i < 10; i++) arr.add(i);
        check("ResizableArray grows", arr.size() == 10 && arr.capacity() >= 10);
        arr.removeAt(0);
        check("ResizableArray removeAt shifts", arr.get(0) == 1 && arr.size() == 9);

        SinglyLinkedList<String> list = new SinglyLinkedList<>();
        list.append("a"); list.append("b"); list.append("c");
        check("LinkedList keeps order", list.get(0).equals("a") && list.getLast().equals("c"));

        CustomQueue<Integer> q = new CustomQueue<>();
        q.enqueue(1); q.enqueue(2); q.enqueue(3);
        check("Queue FIFO", q.dequeue() == 1 && q.peek() == 2);
        q.remove(3);
        check("Queue remove", q.size() == 1);

        HarvestService hs = new HarvestService(new ResizableArray<>(), 1);
        hs.submitHarvest("Lettuce", "Vegetable", "Farm", 50, 48, LocalDateTime.now().minusHours(40), 10);
        hs.submitHarvest("Broccoli", "Vegetable", "Farm", 35, 72, LocalDateTime.now(), 10);
        hs.processQueue();
        check("Queue processes in order", hs.getBatches().get(0).getCrop().equals("Lettuce"));
        check("Old lettuce is Near Spoilage", hs.getBatches().get(0).getFreshness() == Batch.Freshness.NEAR_SPOILAGE);
        check("New broccoli is Fresh", hs.getBatches().get(1).getFreshness() == Batch.Freshness.FRESH);

        AlertQueueService as = new AlertQueueService(new CustomQueue<>(), new ResizableArray<>());
        check("Alert flagged", as.flagIfNeeded(hs.getBatches().get(0)));
        check("No duplicate alert", !as.flagIfNeeded(hs.getBatches().get(0)));
        as.resolve(as.getPending().peek(), true);
        check("Rescued kg tracked", as.kgRescued() == 50);

        RouteNode a = new RouteNode("A", RouteNode.Kind.FARM, 0, 0), b = new RouteNode("B", RouteNode.Kind.HUB, 0, 0),
                c = new RouteNode("C", RouteNode.Kind.MARKET, 0, 0);
        ResizableArray<RouteNode> ns = new ResizableArray<>(); ns.add(a); ns.add(b); ns.add(c);
        ResizableArray<RouteEdge> es = new ResizableArray<>();
        RouteEdge ab = new RouteEdge(a, b, 1, 1), bc = new RouteEdge(b, c, 1, 1), ac = new RouteEdge(a, c, 5, 3);
        es.add(ab); es.add(bc); es.add(ac);
        RoutingService rs = new RoutingService(ns, es);
        check("Dijkstra shortest", rs.shortest(a, c).hours == 2);
        List<RoutingService.Path> k = rs.kShortest(a, c, 3);
        check("Yen's finds alternative", k.size() == 2 && k.get(1).hours == 3);
        rs.reportDelay(bc, 5);
        check("Route recalculated after delay", rs.shortest(a, c).edges.contains(ac));

        System.out.println("\n" + passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }
}
