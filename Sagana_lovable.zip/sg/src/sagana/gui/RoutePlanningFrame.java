package sagana.gui;

import sagana.AppContext;
import sagana.model.RouteEdge;
import sagana.model.RouteNode;
import sagana.service.RoutingService;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class RoutePlanningFrame extends JFrame {
    private final AppContext ctx;
    private final JComboBox<RouteNode> from = new JComboBox<>(), to = new JComboBox<>();
    private final DefaultListModel<String> routesModel = new DefaultListModel<>();
    private final DefaultListModel<String> networkModel = new DefaultListModel<>();
    private List<RoutingService.Path> routes = new ArrayList<>();
    private final MapPanel map = new MapPanel();
    private final CardLayout cards = new CardLayout();
    private final JPanel view = new JPanel(cards);

    public RoutePlanningFrame(AppContext ctx) {
        super("SAGANA - Route Planning");
        this.ctx = ctx;
        setSize(820, 640);
        setLocationRelativeTo(null);

        for (RouteNode n : ctx.routing.nodesOfKind(RouteNode.Kind.FARM)) from.addItem(n);
        for (RouteNode n : ctx.routing.nodesOfKind(RouteNode.Kind.MARKET)) to.addItem(n);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(UI.title("ROUTE PLANNING"));
        JButton mapBtn = new JButton("Map"), netBtn = new JButton("Network");
        mapBtn.addActionListener(e -> cards.show(view, "map"));
        netBtn.addActionListener(e -> cards.show(view, "net"));
        top.add(mapBtn); top.add(netBtn);
        top.add(new JLabel("From:")); top.add(from);
        top.add(new JLabel("To:")); top.add(to);
        JButton compute = UI.button("Find Routes");
        compute.addActionListener(e -> compute());
        top.add(compute);

        view.add(map, "map");
        view.add(new JScrollPane(new JList<>(networkModel)), "net");

        JList<String> routeList = new JList<>(routesModel);
        routeList.addListSelectionListener(e -> {
            int i = routeList.getSelectedIndex();
            map.highlight = i >= 0 && i < routes.size() ? routes.get(i) : null;
            map.repaint();
        });
        JScrollPane rs = new JScrollPane(routeList);
        rs.setBorder(BorderFactory.createTitledBorder("Recommended routes (Dijkstra + Yen's alternatives)"));
        rs.setPreferredSize(new Dimension(800, 110));

        JPanel tools = new JPanel();
        JButton refresh = new JButton("Refresh Map"), zoomOut = new JButton("Zoom Out (-)"),
                reset = new JButton("Reset Zoom"), zoomIn = new JButton("Zoom In (+)"),
                delay = UI.button("Report Road Delay");
        refresh.addActionListener(e -> { reloadNetwork(); compute(); });
        zoomOut.addActionListener(e -> { map.zoom = Math.max(0.4, map.zoom - 0.2); map.repaint(); });
        reset.addActionListener(e -> { map.zoom = 1.0; map.repaint(); });
        zoomIn.addActionListener(e -> { map.zoom = Math.min(3.0, map.zoom + 0.2); map.repaint(); });
        delay.addActionListener(e -> reportDelay());
        tools.add(refresh); tools.add(zoomOut); tools.add(reset); tools.add(zoomIn); tools.add(delay);

        JPanel south = new JPanel(new BorderLayout());
        south.add(rs, BorderLayout.CENTER);
        south.add(tools, BorderLayout.SOUTH);

        add(top, BorderLayout.NORTH);
        add(view, BorderLayout.CENTER);
        add(south, BorderLayout.SOUTH);
        reloadNetwork();
        compute();
    }

    private void reloadNetwork() {
        networkModel.clear();
        for (int i = 0; i < ctx.routing.getEdges().size(); i++) networkModel.addElement(ctx.routing.getEdges().get(i).toString());
        map.repaint();
    }

    private void compute() {
        RouteNode s = (RouteNode) from.getSelectedItem(), d = (RouteNode) to.getSelectedItem();
        routesModel.clear();
        if (s == null || d == null) return;
        routes = ctx.routing.kShortest(s, d, 3);
        if (routes.isEmpty()) routesModel.addElement("No route available.");
        for (int i = 0; i < routes.size(); i++)
            routesModel.addElement((i == 0 ? "BEST: " : "ALT " + i + ": ") + routes.get(i));
        map.highlight = routes.isEmpty() ? null : routes.get(0);
        map.repaint();
    }

    private void reportDelay() {
        RouteEdge[] es = new RouteEdge[ctx.routing.getEdges().size()];
        for (int i = 0; i < es.length; i++) es[i] = ctx.routing.getEdges().get(i);
        JComboBox<RouteEdge> pick = new JComboBox<>(es);
        JTextField hours = new JTextField("0.5");
        Object[] form = {"Road segment:", pick, "Extra delay (hours):", hours};
        if (JOptionPane.showConfirmDialog(this, form, "Report Delay", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;
        try {
            double h = Double.parseDouble(hours.getText().trim());
            if (h <= 0) throw new NumberFormatException();
            ctx.routing.reportDelay((RouteEdge) pick.getSelectedItem(), h);
            reloadNetwork();
            compute(); // dynamic recalculation
        } catch (NumberFormatException ex) {
            UI.error(this, "Delay must be a positive number.");
        }
    }

    private class MapPanel extends JPanel {
        double zoom = 1.0;
        RoutingService.Path highlight;

        MapPanel() { setBackground(UI.LIGHT); }

        @Override protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            Graphics2D g = (Graphics2D) g0;
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.scale(zoom, zoom);
            for (int i = 0; i < ctx.routing.getEdges().size(); i++) {
                RouteEdge e = ctx.routing.getEdges().get(i);
                boolean on = highlight != null && highlight.edges.contains(e);
                g.setColor(on ? UI.ORANGE : Color.GRAY);
                g.setStroke(new BasicStroke(on ? 4 : 2));
                int x1 = e.getFrom().getX(), y1 = e.getFrom().getY(), x2 = e.getTo().getX(), y2 = e.getTo().getY();
                g.drawLine(x1, y1, x2, y2);
                g.setColor(Color.DARK_GRAY);
                g.drawString(String.format("%.1f km / %.1f h", e.getDistanceKm(), e.getHours()), (x1 + x2) / 2 + 4, (y1 + y2) / 2 - 4);
            }
            for (int i = 0; i < ctx.routing.getNodes().size(); i++) {
                RouteNode n = ctx.routing.getNodes().get(i);
                g.setColor(n.getKind() == RouteNode.Kind.FARM ? UI.GREEN : n.getKind() == RouteNode.Kind.MARKET ? UI.RED : Color.BLUE);
                g.fillOval(n.getX() - 8, n.getY() - 8, 16, 16);
                g.setColor(Color.BLACK);
                g.drawString(n.toString(), n.getX() - 30, n.getY() + 22);
            }
        }
    }
}
