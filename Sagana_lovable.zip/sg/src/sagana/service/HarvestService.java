package sagana.service;

import sagana.ds.CustomQueue;
import sagana.ds.ResizableArray;
import sagana.model.Batch;
import sagana.model.BatchEvent;
import java.time.LocalDateTime;

/** Batch registration (via FIFO queue), event logging and freshness estimation. */
public class HarvestService {
    private final ResizableArray<Batch> batches;
    private final CustomQueue<Batch> registrationQueue = new CustomQueue<>();
    private int nextId;

    public HarvestService(ResizableArray<Batch> batches, int nextId) {
        this.batches = batches; this.nextId = nextId;
    }

    /** Places a new harvest into the registration queue. */
    public Batch submitHarvest(String crop, String category, String farm, double kg,
                               int shelfLifeHours, LocalDateTime harvested, double tempC) {
        if (crop.isBlank() || farm.isBlank()) throw new IllegalArgumentException("Crop and farm are required.");
        if (kg <= 0) throw new IllegalArgumentException("Quantity must be greater than 0.");
        if (shelfLifeHours <= 0) throw new IllegalArgumentException("Shelf life must be greater than 0.");
        if (harvested.isAfter(LocalDateTime.now())) throw new IllegalArgumentException("Harvest date cannot be in the future.");
        String id = String.format("B%04d", nextId++);
        Batch b = new Batch(id, crop.trim(), category, farm.trim(), kg, shelfLifeHours, harvested, tempC);
        registrationQueue.enqueue(b);
        return b;
    }

    /** Processes the queue first-come-first-served, storing each batch and assigning freshness. */
    public int processQueue() {
        int count = 0;
        while (!registrationQueue.isEmpty()) {
            Batch b = registrationQueue.dequeue();
            recheckFreshness(b);
            batches.add(b);
            count++;
        }
        return count;
    }

    public void logEvent(Batch b, BatchEvent.Type type, String note) {
        BatchEvent last = b.getEvents().getLast();
        if (last.getType() == BatchEvent.Type.ARRIVED)
            throw new IllegalStateException("Batch has already arrived.");
        if (type == BatchEvent.Type.DISPATCHED && last.getType() != BatchEvent.Type.HARVESTED)
            throw new IllegalStateException("Batch was already dispatched.");
        if (type != BatchEvent.Type.DISPATCHED && last.getType() == BatchEvent.Type.HARVESTED)
            throw new IllegalStateException("Batch must be dispatched first.");
        b.logEvent(new BatchEvent(type, LocalDateTime.now(), note));
        recheckFreshness(b);
    }

    /**
     * Rule-based decay estimation: probability = effective elapsed hours / shelf life,
     * scaled by temperature (each degree above 10 C speeds decay by 4%).
     */
    public Batch.Freshness recheckFreshness(Batch b) {
        double hours = b.effectiveHoursElapsed(LocalDateTime.now());
        double tempFactor = 1 + Math.max(0, b.getStorageTempC() - 10) * 0.04;
        double p = Math.min(1.0, hours * tempFactor / b.getShelfLifeHours());
        b.setSpoilageProbability(p);
        Batch.Freshness f;
        if (p < 0.40) f = Batch.Freshness.FRESH;
        else if (p < 0.70) f = Batch.Freshness.SAFE_FOR_SALE;
        else if (p < 1.0) f = Batch.Freshness.NEAR_SPOILAGE;
        else f = Batch.Freshness.SPOILED;
        b.setFreshness(f);
        return f;
    }

    public void recheckAll() { for (int i = 0; i < batches.size(); i++) recheckFreshness(batches.get(i)); }

    public boolean removeBatch(Batch b) { return batches.remove(b); }

    public ResizableArray<Batch> getBatches() { return batches; }
    public int getNextId() { return nextId; }
}
