package sagana.service;

import sagana.ds.ResizableArray;
import sagana.model.RouteEdge;
import sagana.model.RouteNode;
import java.util.*;

/** Weighted road graph with Dijkstra (shortest travel time) and Yen's k-shortest paths. */
public class RoutingService {
    public static class Path {
        public final List<RouteNode> nodes;
        public final List<RouteEdge> edges;
        public final double hours, km;
        Path(List<RouteNode> nodes, List<RouteEdge> edges) {
            this.nodes = nodes; this.edges = edges;
            double h = 0, k = 0;
            for (RouteEdge e : edges) { h += e.getHours(); k += e.getDistanceKm(); }
            hours = h; km = k;
        }
        @Override public String toString() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < nodes.size(); i++) { if (i > 0) sb.append(" -> "); sb.append(nodes.get(i).getName()); }
            return sb + String.format("   [%.1f km / %.2f h]", km, hours);
        }
    }

    private final ResizableArray<RouteNode> nodes;
    private final ResizableArray<RouteEdge> edges;

    public RoutingService(ResizableArray<RouteNode> nodes, ResizableArray<RouteEdge> edges) {
        this.nodes = nodes; this.edges = edges;
    }

    public ResizableArray<RouteNode> getNodes() { return nodes; }
    public ResizableArray<RouteEdge> getEdges() { return edges; }

    public RouteNode find(String name) {
        for (int i = 0; i < nodes.size(); i++) if (nodes.get(i).getName().equals(name)) return nodes.get(i);
        return null;
    }

    public List<RouteNode> nodesOfKind(RouteNode.Kind k) {
        List<RouteNode> out = new ArrayList<>();
        for (int i = 0; i < nodes.size(); i++) if (nodes.get(i).getKind() == k) out.add(nodes.get(i));
        return out;
    }

    /** Dijkstra on travel hours, ignoring removed edges/nodes (used by Yen's). */
    public Path dijkstra(RouteNode src, RouteNode dst, Set<RouteEdge> bannedEdges, Set<RouteNode> bannedNodes) {
        Map<RouteNode, Double> dist = new HashMap<>();
        Map<RouteNode, RouteEdge> via = new HashMap<>();
        PriorityQueue<Object[]> pq = new PriorityQueue<>(Comparator.comparingDouble(a -> (Double) a[1]));
        dist.put(src, 0.0);
        pq.add(new Object[]{src, 0.0});
        while (!pq.isEmpty()) {
            Object[] top = pq.poll();
            RouteNode u = (RouteNode) top[0];
            double d = (Double) top[1];
            if (d > dist.getOrDefault(u, Double.MAX_VALUE)) continue;
            if (u == dst) break;
            for (int i = 0; i < edges.size(); i++) {
                RouteEdge e = edges.get(i);
                if (e.getFrom() != u && e.getTo() != u) continue;
                if (bannedEdges.contains(e)) continue;
                RouteNode v = e.other(u);
                if (bannedNodes.contains(v)) continue;
                double nd = d + e.getHours();
                if (nd < dist.getOrDefault(v, Double.MAX_VALUE)) {
                    dist.put(v, nd); via.put(v, e); pq.add(new Object[]{v, nd});
                }
            }
        }
        if (!dist.containsKey(dst)) return null;
        LinkedList<RouteNode> pn = new LinkedList<>();
        LinkedList<RouteEdge> pe = new LinkedList<>();
        RouteNode cur = dst;
        pn.addFirst(cur);
        while (cur != src) {
            RouteEdge e = via.get(cur);
            pe.addFirst(e);
            cur = e.other(cur);
            pn.addFirst(cur);
        }
        return new Path(new ArrayList<>(pn), new ArrayList<>(pe));
    }

    public Path shortest(RouteNode src, RouteNode dst) {
        return dijkstra(src, dst, new HashSet<>(), new HashSet<>());
    }

    /** Yen's algorithm: up to k loopless shortest paths, used for alternative routes. */
    public List<Path> kShortest(RouteNode src, RouteNode dst, int k) {
        List<Path> result = new ArrayList<>();
        Path first = shortest(src, dst);
        if (first == null) return result;
        result.add(first);
        List<Path> candidates = new ArrayList<>();
        for (int n = 1; n < k; n++) {
            Path prev = result.get(n - 1);
            for (int i = 0; i < prev.nodes.size() - 1; i++) {
                RouteNode spur = prev.nodes.get(i);
                List<RouteNode> rootNodes = prev.nodes.subList(0, i + 1);
                List<RouteEdge> rootEdges = prev.edges.subList(0, i);
                Set<RouteEdge> banned = new HashSet<>();
                for (Path p : result)
                    if (p.nodes.size() > i && p.nodes.subList(0, i + 1).equals(rootNodes)) banned.add(p.edges.get(i));
                Set<RouteNode> bannedNodes = new HashSet<>(rootNodes);
                bannedNodes.remove(spur);
                Path spurPath = dijkstra(spur, dst, banned, bannedNodes);
                if (spurPath == null) continue;
                List<RouteNode> tn = new ArrayList<>(rootNodes);
                tn.addAll(spurPath.nodes.subList(1, spurPath.nodes.size()));
                List<RouteEdge> te = new ArrayList<>(rootEdges);
                te.addAll(spurPath.edges);
                Path total = new Path(tn, te);
                boolean dup = false;
                for (Path c : candidates) if (c.nodes.equals(total.nodes)) dup = true;
                for (Path c : result) if (c.nodes.equals(total.nodes)) dup = true;
                if (!dup) candidates.add(total);
            }
            if (candidates.isEmpty()) break;
            candidates.sort(Comparator.comparingDouble(p -> p.hours));
            result.add(candidates.remove(0));
        }
        return result;
    }

    /** Reports a delay on a road segment (adds hours), which affects the next route calculation. */
    public void reportDelay(RouteEdge e, double extraHours) { e.setHours(e.getHours() + extraHours); }
}
