SAGANA - Delivery Route Optimization and Spoilage Monitoring (Java Swing)

Requirements: JDK 11 or newer.

Compile:
  javac -d out $(find src -name "*.java")        (Windows: dir /s /b src\*.java > files.txt && javac -d out @files.txt)

Run the app:
  java -cp out sagana.Main
  Login: admin / admin123

Run the tests:
  java -cp out sagana.DataStructureTest

Data is saved to sagana_data.ser on exit, Logout, or "Saved Data".
