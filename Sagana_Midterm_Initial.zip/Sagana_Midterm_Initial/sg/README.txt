SAGANA - Delivery Route Optimization and Spoilage Monitoring (Java Swing)

Requirements: JDK 11 or newer.

Compile:
  javac -d out $(find src -name "*.java")        (Windows: dir /s /b src\*.java > files.txt && javac -d out @files.txt)

Run the app:
  java -cp out sagana.Main
  Login: admin / admin123

Run the tests:
  java -cp out sagana.DataStructureTest

Data is saved to sagana_data.ser on exit, Logout, or "Saved Data".

Route Planning - adding to the network
  Add Location : create a new Farm, Hub or Market. It must be joined to an existing location by a road
                 (distance in km; travel time in hours, or leave blank to estimate at 35 km/h).
                 The map position is chosen automatically. Names must be unique.
  Add Road     : join two existing locations (no duplicates, distance and time must be > 0).
  New locations and roads are saved with the rest of the data and used by Dijkstra / Yen's immediately.

Note: storage temperature was removed from the system. Freshness is now
  spoilage probability = (hours since harvest + 6 h per reported delay) / shelf life.
  If you upgrade from an older build, delete sagana_data.ser once (the old file has a different Batch format).
