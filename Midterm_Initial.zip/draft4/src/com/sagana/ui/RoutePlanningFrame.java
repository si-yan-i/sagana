package com.sagana.ui;

import com.sagana.datastructures.ResizableArray;
import com.sagana.model.Batch;
import com.sagana.model.NodeType;
import com.sagana.model.RouteEdge;
import com.sagana.model.RouteNode;
import com.sagana.service.AppContext;
import com.sagana.service.RouteResult;
import com.sagana.util.ValidationUtil;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * Route Planning / Delivery Monitoring screen (Midterm scope). Lets the
 * admin register the delivery network (nodes and routes between them),
 * compute the Dijkstra-recommended market for a selected batch, and view
 * the network as a schematic map with the recommended route highlighted.
 */
public class RoutePlanningFrame extends JFrame {

    private DefaultListModel<RouteNode> nodeListModel;
    private DefaultListModel<RouteEdge> edgeListModel;
    private JList<RouteNode> nodeList;
    private JList<RouteEdge> edgeList;
    private RouteMapPanel mapPanel;
    private JTabbedPane tabs;

    public RoutePlanningFrame() {
        setTitle("SAGANA — Route Planning");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(820, 640);
        setLocationRelativeTo(null);

        tabs = new JTabbedPane();
        tabs.addTab("Network", buildNetworkTab());
        tabs.addTab("Map", buildMapTab());

        add(tabs);
        reloadLists();
    }

    // ---------- Network tab: existing location/route management ----------

    private JPanel buildNetworkTab() {
        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel header = new JLabel("Route Planning — Delivery Network");
        header.setFont(new Font("SansSerif", Font.BOLD, 18));
        root.add(header, BorderLayout.NORTH);

        JPanel lists = new JPanel(new GridLayout(1, 2, 10, 0));

        JPanel nodePanel = new JPanel(new BorderLayout(4, 4));
        nodePanel.setBorder(BorderFactory.createTitledBorder("Locations"));
        nodeListModel = new DefaultListModel<>();
        nodeList = new JList<>(nodeListModel);
        nodePanel.add(new JScrollPane(nodeList), BorderLayout.CENTER);
        JButton addNodeBtn = new JButton("Add Location");
        JButton deleteNodeBtn = new JButton("Delete Location");
        JPanel nodeButtons = new JPanel(new GridLayout(1, 2, 4, 0));
        nodeButtons.add(addNodeBtn);
        nodeButtons.add(deleteNodeBtn);
        nodePanel.add(nodeButtons, BorderLayout.SOUTH);
        lists.add(nodePanel);

        JPanel edgePanel = new JPanel(new BorderLayout(4, 4));
        edgePanel.setBorder(BorderFactory.createTitledBorder("Routes"));
        edgeListModel = new DefaultListModel<>();
        edgeList = new JList<>(edgeListModel);
        edgePanel.add(new JScrollPane(edgeList), BorderLayout.CENTER);
        JButton addEdgeBtn = new JButton("Add Route");
        JButton deleteEdgeBtn = new JButton("Delete Route");
        JPanel edgeButtons = new JPanel(new GridLayout(1, 2, 4, 0));
        edgeButtons.add(addEdgeBtn);
        edgeButtons.add(deleteEdgeBtn);
        edgePanel.add(edgeButtons, BorderLayout.SOUTH);
        lists.add(edgePanel);

        root.add(lists, BorderLayout.CENTER);

        JButton computeBtn = new JButton("Compute Best Route for Batch");
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottom.add(computeBtn);
        root.add(bottom, BorderLayout.SOUTH);

        addNodeBtn.addActionListener(e -> openAddNodeDialog());
        deleteNodeBtn.addActionListener(e -> deleteSelectedNode());
        addEdgeBtn.addActionListener(e -> openAddEdgeDialog());
        deleteEdgeBtn.addActionListener(e -> deleteSelectedEdge());
        computeBtn.addActionListener(e -> openComputeRouteDialog());

        return root;
    }

    // ---------- Map tab: schematic visualization ----------

    private JPanel buildMapTab() {
        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel note = new JLabel("Schematic layout from each location's lat/lng — not a real street map.");
        note.setFont(note.getFont().deriveFont(Font.ITALIC, 12f));
        root.add(note, BorderLayout.NORTH);

        mapPanel = new RouteMapPanel(AppContext.ROUTING_SERVICE.getAllNodes(), AppContext.ROUTING_SERVICE.getAllEdges());
        root.add(new JScrollPane(mapPanel), BorderLayout.CENTER);

        JButton refreshBtn = new JButton("Refresh Map");
        refreshBtn.addActionListener(e ->
                mapPanel.refreshData(AppContext.ROUTING_SERVICE.getAllNodes(), AppContext.ROUTING_SERVICE.getAllEdges()));

        JButton zoomInBtn = new JButton("Zoom In (+)");
        JButton zoomOutBtn = new JButton("Zoom Out (−)");
        JButton zoomResetBtn = new JButton("Reset Zoom");
        zoomInBtn.addActionListener(e -> mapPanel.zoomIn());
        zoomOutBtn.addActionListener(e -> mapPanel.zoomOut());
        zoomResetBtn.addActionListener(e -> mapPanel.resetZoom());

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottom.add(refreshBtn);
        bottom.add(zoomOutBtn);
        bottom.add(zoomResetBtn);
        bottom.add(zoomInBtn);
        root.add(bottom, BorderLayout.SOUTH);

        return root;
    }

    private void reloadLists() {
        nodeListModel.clear();
        ResizableArray<RouteNode> nodes = AppContext.ROUTING_SERVICE.getAllNodes();
        for (int i = 0; i < nodes.size(); i++) nodeListModel.addElement(nodes.get(i));

        edgeListModel.clear();
        ResizableArray<RouteEdge> edges = AppContext.ROUTING_SERVICE.getAllEdges();
        for (int i = 0; i < edges.size(); i++) edgeListModel.addElement(edges.get(i));

        if (mapPanel != null) {
            mapPanel.refreshData(AppContext.ROUTING_SERVICE.getAllNodes(), AppContext.ROUTING_SERVICE.getAllEdges());
        }
    }

    private void deleteSelectedNode() {
        RouteNode selected = nodeList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Select a location in the list first.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete \"" + selected.getName() + "\"?\nAny routes connected to it will be deleted too.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;

        AppContext.ROUTING_SERVICE.removeNode(selected.getNodeId());
        reloadLists();
    }

    private void deleteSelectedEdge() {
        RouteEdge selected = edgeList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Select a route in the list first.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete this route?\n" + selected,
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;

        AppContext.ROUTING_SERVICE.removeEdge(selected.getEdgeId());
        reloadLists();
    }

    private void openAddNodeDialog() {
        JTextField nameField = new JTextField();
        JComboBox<NodeType> typeBox = new JComboBox<>(NodeType.values());
        JTextField latField = new JTextField();
        JTextField lngField = new JTextField();

        JPanel form = new JPanel(new GridLayout(0, 2, 6, 6));
        form.add(new JLabel("Name:"));
        form.add(nameField);
        form.add(new JLabel("Type:"));
        form.add(typeBox);
        form.add(new JLabel("Latitude:"));
        form.add(latField);
        form.add(new JLabel("Longitude:"));
        form.add(lngField);

        int result = JOptionPane.showConfirmDialog(this, form, "Add Location",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;

        if (ValidationUtil.isBlank(nameField.getText())) {
            JOptionPane.showMessageDialog(this, "Please enter a name.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double lat = parseOrZero(latField.getText());
        double lng = parseOrZero(lngField.getText());

        AppContext.ROUTING_SERVICE.addNode(nameField.getText().trim(),
                (NodeType) typeBox.getSelectedItem(), lat, lng);
        reloadLists();
    }

    private void openAddEdgeDialog() {
        ResizableArray<RouteNode> nodes = AppContext.ROUTING_SERVICE.getAllNodes();
        if (nodes.size() < 2) {
            JOptionPane.showMessageDialog(this, "Add at least two locations first.");
            return;
        }

        RouteNode[] nodeArray = nodes.toArray(new RouteNode[0]);
        JComboBox<RouteNode> fromBox = new JComboBox<>(nodeArray);
        JComboBox<RouteNode> toBox = new JComboBox<>(nodeArray);
        JTextField distanceField = new JTextField();
        JTextField hoursField = new JTextField();

        JPanel form = new JPanel(new GridLayout(0, 2, 6, 6));
        form.add(new JLabel("From:"));
        form.add(fromBox);
        form.add(new JLabel("To:"));
        form.add(toBox);
        form.add(new JLabel("Distance (km):"));
        form.add(distanceField);
        form.add(new JLabel("Base travel time (hours):"));
        form.add(hoursField);

        int result = JOptionPane.showConfirmDialog(this, form, "Add Route",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;

        RouteNode from = (RouteNode) fromBox.getSelectedItem();
        RouteNode to = (RouteNode) toBox.getSelectedItem();

        if (from.getNodeId().equals(to.getNodeId())
                || !ValidationUtil.isPositiveNumber(distanceField.getText())
                || !ValidationUtil.isPositiveNumber(hoursField.getText())) {
            JOptionPane.showMessageDialog(this,
                    "Choose two different locations and enter positive numbers.",
                    "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return;
        }

        AppContext.ROUTING_SERVICE.addEdge(from.getNodeId(), to.getNodeId(),
                Double.parseDouble(distanceField.getText().trim()),
                Double.parseDouble(hoursField.getText().trim()));
        reloadLists();
    }

    private void openComputeRouteDialog() {
        ResizableArray<Batch> batches = AppContext.HARVEST_SERVICE.getAllBatches();
        ResizableArray<RouteNode> nodes = AppContext.ROUTING_SERVICE.getAllNodes();

        if (batches.isEmpty() || nodes.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Register at least one batch and one location first.");
            return;
        }

        // Destination choices: an automatic option first, then every market.
        // Only MARKET nodes are offered, since farms and waypoints aren't delivery destinations.
        final String AUTO_OPTION = "Nearest market (automatic)";
        JComboBox<Object> destinationBox = new JComboBox<>();
        destinationBox.addItem(AUTO_OPTION);
        int marketCount = 0;
        for (int i = 0; i < nodes.size(); i++) {
            if (nodes.get(i).getType() == NodeType.MARKET) {
                destinationBox.addItem(nodes.get(i));
                marketCount++;
            }
        }
        if (marketCount == 0) {
            JOptionPane.showMessageDialog(this, "Add at least one MARKET location first.");
            return;
        }

        Batch[] batchArray = batches.toArray(new Batch[0]);
        RouteNode[] nodeArray = nodes.toArray(new RouteNode[0]);
        JComboBox<Batch> batchBox = new JComboBox<>(batchArray);
        JComboBox<RouteNode> sourceBox = new JComboBox<>(nodeArray);

        JPanel form = new JPanel(new GridLayout(0, 2, 6, 6));
        form.add(new JLabel("Batch:"));
        form.add(batchBox);
        form.add(new JLabel("Current location:"));
        form.add(sourceBox);
        form.add(new JLabel("Destination market:"));
        form.add(destinationBox);

        int result = JOptionPane.showConfirmDialog(this, form, "Compute Best Route",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;

        Batch batch = (Batch) batchBox.getSelectedItem();
        RouteNode source = (RouteNode) sourceBox.getSelectedItem();
        Object chosenDestination = destinationBox.getSelectedItem();

        // Either the user picked a specific market, or we let Dijkstra's choose the cheapest one.
        String destinationId;
        if (chosenDestination instanceof RouteNode) {
            destinationId = ((RouteNode) chosenDestination).getNodeId();
        } else {
            RouteResult auto = AppContext.ROUTING_SERVICE.recommendRoute(batch, source.getNodeId());
            destinationId = auto.getDestinationNodeId(); // null if no market is reachable
        }

        String message;
        List<RouteResult> alternates = destinationId == null
                ? List.of()
                : AppContext.ROUTING_SERVICE.findTopRoutes(batch, source.getNodeId(), destinationId, 3);

        if (destinationId != null && source.getNodeId().equals(destinationId)) {
            message = "The batch is already at " + source.getName() + ".";
            mapPanel.setHighlightedPath(null);
        } else if (alternates.isEmpty()) {
            String target = chosenDestination instanceof RouteNode
                    ? ((RouteNode) chosenDestination).getName() : "any market";
            message = "No route exists from " + source.getName() + " to " + target
                    + ".\nCheck that the locations between them are connected by routes.";
            mapPanel.setHighlightedPath(null);
        } else {
            RouteNode destination = AppContext.ROUTING_SERVICE.findNodeById(destinationId);

            StringBuilder sb = new StringBuilder();
            sb.append("Batch ").append(batch.getBatchId())
                    .append(" (").append(batch.computeFreshnessStatus()).append(")\n");
            sb.append("Destination market: ").append(destination.getName())
                    .append(chosenDestination instanceof RouteNode ? " (your choice)" : " (nearest)")
                    .append("\n\n");

            for (int i = 0; i < alternates.size(); i++) {
                RouteResult alt = alternates.get(i);
                sb.append(String.format("Option %d%s: %s  (cost %.2f)%n",
                        i + 1, i == 0 ? " — recommended" : "",
                        String.join(" -> ", alt.getPath()), alt.getTotalCost()));
            }
            message = sb.toString();

            mapPanel.refreshData(AppContext.ROUTING_SERVICE.getAllNodes(), AppContext.ROUTING_SERVICE.getAllEdges());
            mapPanel.setHighlightedPath(alternates.get(0).getPath());
            tabs.setSelectedIndex(1); // jump to Map tab so the highlighted route is visible immediately
        }

        JOptionPane.showMessageDialog(this, message, "Route Recommendation", JOptionPane.INFORMATION_MESSAGE);
    }

    private double parseOrZero(String value) {
        try {
            return Double.parseDouble(value.trim());
        } catch (Exception e) {
            return 0.0;
        }
    }
}