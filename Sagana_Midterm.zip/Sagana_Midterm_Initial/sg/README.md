# SAGANA — Java Midterm Build

A **Java Swing desktop prototype** for harvest registration, freshness tracking,
route planning, near-spoilage alerts, and contact-based food rescue.

## Java Version

- Built and tested with **JDK 17**; also compiles with `--release 11` (JDK 11+ works).

## Software Requirements

- JDK 11 or newer (`javac` and `java` on the PATH)
- Windows, macOS, or Linux
- No external libraries, database, or internet connection

## Package: `sagana`

| File | DSA Component | Feature |
|---|---|---|
| `ds/ResizableArray.java` | Dynamic array | Stores batches, users, places, roads, resolved alerts |
| `ds/SinglyLinkedList.java` | Singly linked list | Batch event history |
| `ds/CustomQueue.java` | FIFO queue | Harvest registrations and pending alerts |
| `model/*.java` | Model classes | Batch, BatchEvent, Alert, RouteNode, RouteEdge, User |
| `service/AccountService.java` | Linear search | Login and role-based access |
| `service/HarvestService.java` | Rule-based scoring | Harvest registration and freshness tracking |
| `service/RoutingService.java` | Weighted graph + Dijkstra + Yen's k-shortest (k=3) | Route planning and delay re-routing |
| `service/AlertQueueService.java` | Queue processing | Near-spoilage alerts and rescued-food report |
| `service/PersistenceService.java` | Java serialization | Local saving (`sagana_data.ser`) |
| `gui/*.java` | Swing frames | Login, Dashboard, Harvest, Batch Details, Alerts, Routes, Accounts, Rescue Board |
| `Main.java` | — | Starts the login screen |
| `DataStructureTest.java` | — | 21 automated checks |

## Setup Procedure

1. Unzip the project into any folder.
2. Open a terminal inside the `Sagana` folder.
3. Compile:

```bash
# Linux / macOS
javac -d out $(find src -name "*.java")

# Windows (Command Prompt)
dir /s /b src\*.java > files.txt
javac -d out @files.txt
```

## How to Run

```bash
java -cp out sagana.Main               # start the app
java -cp out sagana.DataStructureTest  # run checks (21 passed, 0 failed)
```

| Username | Password | Role |
|---|---|---|
| `admin` | `admin123` | Administrator |
| `producer` | `producer123` | Producer |
| `transporter` | `transporter123` | Transporter |
| `rescue` | `rescue123` | Food Rescue Group |

## Sample Inputs

| Screen | Input |
|---|---|
| Register Harvest | Lettuce, Leafy Green, Fresh Start Organic Farm, 50 kg, shelf life 48 hrs, harvested `2026-10-27 08:00` |
| Batch Details | Log Dispatched → Log Delayed → Log Arrived |
| Report Road Delay | Alijis Junction → Tangub Crossing, +0.5 hrs, then Find Routes |
| Add Place | Banago Depot, HUB, X 350, Y 250 |
| Add Road | Alijis Junction → Banago Depot, 4.0 km, 0.2 hrs |
| Add Account | producer2 / farm1234, Producer, Green Valley Farm |

## Completed Functions (Midterm)

1. Login with role-based access (Administrator, Producer, Transporter, Food Rescue Group).
2. Harvest registration and batch listing.
3. Freshness tracking: `(hours since harvest + 6 × delays) ÷ shelf life`
   → Fresh (< 0.40), Safe for Sale (0.40–0.70), Near Spoilage (0.70–1.00), Spoiled (≥ 1.00).
4. Delivery logging: dispatched, delayed, arrived.
5. Route planning with Dijkstra and top-3 alternate routes; re-routing after a reported delay.
6. Adding places (farm, hub, market) and roads.
7. Near-spoilage alert queue and resolving alerts.
8. View-only rescue board with producer contact links (no reservations) and rescued-food report.
9. Account management (admin only).
10. Local saving and loading of data.

## Known Limitations

- Desktop prototype only; data is saved to a local file, not a database.
- Passwords are stored in plain text in the local file.
- Freshness thresholds, the 6-hour delay penalty, and 2.5 meals/kg are estimates.
- No live GPS navigation; route times are entered manually.
- The harvest form still has a storage temperature field (set it to 10 to match the formula above).
