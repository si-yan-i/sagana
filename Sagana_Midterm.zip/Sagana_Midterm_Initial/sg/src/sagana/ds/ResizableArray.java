package sagana.ds;

import java.io.Serializable;

/** Dynamic array that doubles its capacity when full. Stores batch records. */
public class ResizableArray<T> implements Serializable {
    private Object[] data = new Object[4];
    private int size = 0;

    public void add(T item) {
        if (size == data.length) {
            Object[] bigger = new Object[data.length * 2];
            System.arraycopy(data, 0, bigger, 0, size);
            data = bigger;
        }
        data[size++] = item;
    }

    @SuppressWarnings("unchecked")
    public T get(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException("Index: " + index);
        return (T) data[index];
    }

    public T removeAt(int index) {
        T item = get(index);
        System.arraycopy(data, index + 1, data, index, size - index - 1);
        data[--size] = null;
        return item;
    }

    public boolean remove(T item) {
        for (int i = 0; i < size; i++) {
            if (data[i].equals(item)) { removeAt(i); return true; }
        }
        return false;
    }

    public int size() { return size; }
    public boolean isEmpty() { return size == 0; }
    public int capacity() { return data.length; }
}
