package sagana.ds;

import java.io.Serializable;

/** Singly linked list with tail pointer. Stores a batch's chronological event history. */
public class SinglyLinkedList<T> implements Serializable {
    private static class Node<T> implements Serializable {
        T value; Node<T> next;
        Node(T value) { this.value = value; }
    }

    private Node<T> head, tail;
    private int size = 0;

    public void append(T value) {
        Node<T> n = new Node<>(value);
        if (head == null) head = tail = n;
        else { tail.next = n; tail = n; }
        size++;
    }

    public T get(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException("Index: " + index);
        Node<T> cur = head;
        for (int i = 0; i < index; i++) cur = cur.next;
        return cur.value;
    }

    public T getLast() { return tail == null ? null : tail.value; }
    public int size() { return size; }
    public boolean isEmpty() { return size == 0; }
}
