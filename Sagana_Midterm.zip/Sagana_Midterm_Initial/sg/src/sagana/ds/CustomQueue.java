package sagana.ds;

import java.io.Serializable;

/** FIFO queue backed by linked nodes. Used for harvest registration and alert processing. */
public class CustomQueue<T> implements Serializable {
    private static class Node<T> implements Serializable {
        T value; Node<T> next;
        Node(T value) { this.value = value; }
    }

    private Node<T> front, rear;
    private int size = 0;

    public void enqueue(T value) {
        Node<T> n = new Node<>(value);
        if (rear == null) front = rear = n;
        else { rear.next = n; rear = n; }
        size++;
    }

    public T dequeue() {
        if (front == null) throw new IllegalStateException("Queue is empty");
        T v = front.value;
        front = front.next;
        if (front == null) rear = null;
        size--;
        return v;
    }

    public T peek() { return front == null ? null : front.value; }

    /** Returns the element at position i from the front (for display only). */
    public T get(int i) {
        if (i < 0 || i >= size) throw new IndexOutOfBoundsException("Index: " + i);
        Node<T> cur = front;
        for (int k = 0; k < i; k++) cur = cur.next;
        return cur.value;
    }

    /** Removes the first matching element, preserving order of the rest. */
    public boolean remove(T value) {
        Node<T> prev = null, cur = front;
        while (cur != null) {
            if (cur.value.equals(value)) {
                if (prev == null) front = cur.next; else prev.next = cur.next;
                if (cur == rear) rear = prev;
                size--;
                return true;
            }
            prev = cur; cur = cur.next;
        }
        return false;
    }

    public int size() { return size; }
    public boolean isEmpty() { return size == 0; }
}
