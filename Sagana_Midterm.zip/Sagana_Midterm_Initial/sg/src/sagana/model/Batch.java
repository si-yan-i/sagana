package sagana.model;

import sagana.ds.SinglyLinkedList;
import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDateTime;

public class Batch implements Serializable {
    public enum Freshness { FRESH, SAFE_FOR_SALE, NEAR_SPOILAGE, SPOILED;
        public String label() {
            switch (this) {
                case FRESH: return "Fresh";
                case SAFE_FOR_SALE: return "Safe for Sale";
                case NEAR_SPOILAGE: return "Near Spoilage";
                default: return "Spoiled";
            }
        }
    }

    private final String id, crop, category, farm;
    private final double quantityKg;
    private final int shelfLifeHours;
    private final LocalDateTime harvestDate;
    private Freshness freshness = Freshness.FRESH;
    private double spoilageProbability = 0;
    private final SinglyLinkedList<BatchEvent> events = new SinglyLinkedList<>();

    public Batch(String id, String crop, String category, String farm, double quantityKg,
                 int shelfLifeHours, LocalDateTime harvestDate) {
        this.id = id; this.crop = crop; this.category = category; this.farm = farm;
        this.quantityKg = quantityKg; this.shelfLifeHours = shelfLifeHours;
        this.harvestDate = harvestDate;
        events.append(new BatchEvent(BatchEvent.Type.HARVESTED, harvestDate, "Batch registered"));
    }

    public void logEvent(BatchEvent e) { events.append(e); }

    /** Hours elapsed since harvest, plus 6 hours penalty per reported delay. */
    public double effectiveHoursElapsed(LocalDateTime now) {
        double hours = Duration.between(harvestDate, now).toMinutes() / 60.0;
        for (int i = 0; i < events.size(); i++)
            if (events.get(i).getType() == BatchEvent.Type.DELAYED) hours += 6;
        return Math.max(0, hours);
    }

    /** Hours remaining before predicted spoilage. */
    public double remainingShelfLife(LocalDateTime now) {
        return Math.max(0, shelfLifeHours * (1 - spoilageProbability));
    }

    public String getId() { return id; }
    public String getCrop() { return crop; }
    public String getCategory() { return category; }
    public String getFarm() { return farm; }
    public double getQuantityKg() { return quantityKg; }
    public int getShelfLifeHours() { return shelfLifeHours; }
    public LocalDateTime getHarvestDate() { return harvestDate; }
    public Freshness getFreshness() { return freshness; }
    public void setFreshness(Freshness f) { freshness = f; }
    public double getSpoilageProbability() { return spoilageProbability; }
    public void setSpoilageProbability(double p) { spoilageProbability = p; }
    public SinglyLinkedList<BatchEvent> getEvents() { return events; }

    @Override public String toString() {
        return "#" + id + "  " + crop + " (" + category + ")  " + quantityKg + " kg";
    }
}
