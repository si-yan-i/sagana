package sagana.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class BatchEvent implements Serializable {
    public enum Type { HARVESTED, DISPATCHED, DELAYED, ARRIVED }

    public static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("MMM d, yyyy h:mm a");

    private final Type type;
    private final LocalDateTime timestamp;
    private final String note;

    public BatchEvent(Type type, LocalDateTime timestamp, String note) {
        this.type = type; this.timestamp = timestamp; this.note = note;
    }

    public Type getType() { return type; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public String getNote() { return note; }

    @Override public String toString() {
        return type + " - " + timestamp.format(FMT) + " (" + note + ")";
    }
}
