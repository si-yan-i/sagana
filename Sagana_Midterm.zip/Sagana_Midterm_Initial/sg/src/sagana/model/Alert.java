package sagana.model;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Alert implements Serializable {
    public enum Status { PENDING, RESOLVED }

    private final Batch batch;
    private final LocalDateTime detected;
    private Status status = Status.PENDING;
    private String resolution = "";

    public Alert(Batch batch, LocalDateTime detected) { this.batch = batch; this.detected = detected; }

    public Batch getBatch() { return batch; }
    public LocalDateTime getDetected() { return detected; }
    public Status getStatus() { return status; }
    public String getResolution() { return resolution; }
    public void resolve(String resolution) { this.status = Status.RESOLVED; this.resolution = resolution; }

    @Override public String toString() {
        return "#" + batch.getId() + "  " + batch.getCrop() + "  " + batch.getQuantityKg() + " kg  ["
                + (status == Status.PENDING ? "High Spoilage" : resolution) + "]";
    }
}
