package sagana.model;

import java.io.Serializable;

public class RouteNode implements Serializable {
    public enum Kind { FARM, HUB, MARKET }

    private final String name;
    private final Kind kind;
    private final int x, y; // map coordinates

    public RouteNode(String name, Kind kind, int x, int y) {
        this.name = name; this.kind = kind; this.x = x; this.y = y;
    }

    public String getName() { return name; }
    public Kind getKind() { return kind; }
    public int getX() { return x; }
    public int getY() { return y; }

    @Override public String toString() { return name + " (" + kind + ")"; }
}
