package sagana.model;

import java.io.Serializable;

public class RouteEdge implements Serializable {
    private final RouteNode from, to;
    private final double distanceKm;
    private double hours;

    public RouteEdge(RouteNode from, RouteNode to, double distanceKm, double hours) {
        this.from = from; this.to = to; this.distanceKm = distanceKm; this.hours = hours;
    }

    public RouteNode getFrom() { return from; }
    public RouteNode getTo() { return to; }
    public double getDistanceKm() { return distanceKm; }
    public double getHours() { return hours; }
    public void setHours(double h) { hours = h; }

    public RouteNode other(RouteNode n) { return n == from ? to : from; }

    @Override public String toString() {
        return from.getName() + " <-> " + to.getName()
                + String.format("  %.1f km / %.1f h", distanceKm, hours);
    }
}
