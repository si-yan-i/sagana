package sagana.gui;

import sagana.AppContext;
import sagana.model.Batch;
import sagana.model.BatchEvent;
import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;

public class BatchDetailsFrame extends JFrame {
    private final AppContext ctx;
    private final Batch batch;
    private final Runnable onChange;
    private final JLabel info = new JLabel();
    private final DefaultListModel<String> timeline = new DefaultListModel<>();

    public BatchDetailsFrame(AppContext ctx, Batch batch, Runnable onChange) {
        super("SAGANA - Batch Details #" + batch.getId());
        this.ctx = ctx; this.batch = batch; this.onChange = onChange;
        setSize(520, 520);
        setLocationRelativeTo(null);

        info.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        JPanel top = new JPanel(new BorderLayout());
        top.add(UI.title("BATCH DETAILS  #" + batch.getId()), BorderLayout.NORTH);
        top.add(info, BorderLayout.CENTER);

        JList<String> list = new JList<>(timeline);
        JScrollPane sp = new JScrollPane(list);
        sp.setBorder(BorderFactory.createTitledBorder("Freshness Timeline (Event History)"));

        JPanel actions = new JPanel(new GridLayout(2, 2, 6, 6));
        JButton d = UI.button("Log Dispatched"), dl = UI.button("Log Delayed"),
                a = UI.button("Log Arrived"), r = UI.button("Recheck Freshness / Flag Alert");
        d.addActionListener(e -> log(BatchEvent.Type.DISPATCHED, "Batch dispatched for delivery"));
        dl.addActionListener(e -> {
            String reason = JOptionPane.showInputDialog(this, "Delay reason:", "Delay reported in transit");
            if (reason != null) log(BatchEvent.Type.DELAYED, reason.isBlank() ? "Delay reported in transit" : reason);
        });
        a.addActionListener(e -> log(BatchEvent.Type.ARRIVED, "Batch arrived at destination"));
        r.addActionListener(e -> recheck());
        actions.add(d); actions.add(dl); actions.add(a); actions.add(r);

        add(top, BorderLayout.NORTH);
        add(sp, BorderLayout.CENTER);
        add(actions, BorderLayout.SOUTH);
        refresh();
    }

    private void log(BatchEvent.Type type, String note) {
        try {
            ctx.harvest.logEvent(batch, type, note);
            ctx.alerts.flagIfNeeded(batch);
            refresh();
            onChange.run();
        } catch (IllegalStateException ex) {
            UI.error(this, ex.getMessage());
        }
    }

    private void recheck() {
        Batch.Freshness f = ctx.harvest.recheckFreshness(batch);
        boolean flagged = ctx.alerts.flagIfNeeded(batch);
        String msg = "Freshness: " + f.label() + String.format(" (spoilage probability %.2f)", batch.getSpoilageProbability());
        if (flagged) msg += "\nNear-spoilage alert flagged for food rescue partners.";
        else if (ctx.alerts.hasPending(batch)) msg += "\nAn alert is already pending for this batch.";
        JOptionPane.showMessageDialog(this, msg);
        refresh();
        onChange.run();
    }

    private void refresh() {
        Batch b = batch;
        info.setText("<html>Farm: " + b.getFarm() + "<br>Category: " + b.getCrop() + " (" + b.getCategory() + ")"
                + "<br>Quantity: " + b.getQuantityKg() + " kg<br>Shelf Life: " + b.getShelfLifeHours() + " hrs"
                + String.format("<br>Remaining: %.0f hrs", b.remainingShelfLife(LocalDateTime.now()))
                + "<br>Freshness Status: <b>" + b.getFreshness().label() + "</b></html>");
        info.setForeground(UI.statusColor(b.getFreshness()));
        timeline.clear();
        for (int i = 0; i < b.getEvents().size(); i++) timeline.addElement("\u25CF " + b.getEvents().get(i));
    }
}
