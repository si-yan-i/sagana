package sagana.gui;

import sagana.AppContext;
import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    private static final String USER = "admin", PASS = "admin123";

    public LoginFrame(AppContext ctx) {
        super("SAGANA - Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(380, 260);
        setLocationRelativeTo(null);

        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(UI.LIGHT);
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6, 6, 6, 6);
        c.fill = GridBagConstraints.HORIZONTAL;

        JTextField user = new JTextField(15);
        JPasswordField pass = new JPasswordField(15);
        JButton login = UI.button("Login");

        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        p.add(UI.title("SAGANA Farm to Market"), c);
        c.gridwidth = 1; c.gridy = 1; p.add(new JLabel("Username"), c);
        c.gridx = 1; p.add(user, c);
        c.gridx = 0; c.gridy = 2; p.add(new JLabel("Password"), c);
        c.gridx = 1; p.add(pass, c);
        c.gridx = 0; c.gridy = 3; c.gridwidth = 2; p.add(login, c);

        Runnable doLogin = () -> {
            if (USER.equals(user.getText().trim()) && PASS.equals(new String(pass.getPassword()))) {
                new DashboardFrame(ctx).setVisible(true);
                dispose();
            } else UI.error(this, "Invalid username or password.");
        };
        login.addActionListener(e -> doLogin.run());
        pass.addActionListener(e -> doLogin.run());
        add(p);
    }
}
