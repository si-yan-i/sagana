package sagana.gui;

import sagana.AppContext;
import sagana.model.Alert;
import sagana.model.BatchEvent;
import javax.swing.*;
import java.awt.*;

public class AlertQueueFrame extends JFrame {
    private final AppContext ctx;
    private final Runnable onChange;
    private final DefaultListModel<Alert> pendingModel = new DefaultListModel<>();
    private final DefaultListModel<Alert> resolvedModel = new DefaultListModel<>();
    private final JList<Alert> pendingList = new JList<>(pendingModel);
    private final JList<Alert> resolvedList = new JList<>(resolvedModel);
    private final JTabbedPane tabs = new JTabbedPane();

    public AlertQueueFrame(AppContext ctx, Runnable onChange) {
        super("SAGANA - Near-Spoilage Alerts");
        this.ctx = ctx; this.onChange = onChange;
        setSize(560, 420);
        setLocationRelativeTo(null);

        tabs.addTab("Pending", new JScrollPane(pendingList));
        tabs.addTab("Resolved", new JScrollPane(resolvedList));

        JPanel buttons = new JPanel();
        JButton details = UI.button("View Details"), rescue = UI.button("Mark Rescued"), dismiss = UI.button("Dismiss");
        details.addActionListener(e -> showDetails());
        rescue.addActionListener(e -> resolve(true));
        dismiss.addActionListener(e -> resolve(false));
        buttons.add(details); buttons.add(rescue); buttons.add(dismiss);

        add(UI.title("NEAR-SPOILAGE ALERTS"), BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);
        refresh();
    }

    private Alert selected() {
        JList<Alert> l = tabs.getSelectedIndex() == 0 ? pendingList : resolvedList;
        Alert a = l.getSelectedValue();
        if (a == null) UI.error(this, "Select an alert first.");
        return a;
    }

    private void showDetails() {
        Alert a = selected();
        if (a == null) return;
        JOptionPane.showMessageDialog(this,
                "Batch: #" + a.getBatch().getId() + " " + a.getBatch().getCrop()
                        + "\nQuantity: " + a.getBatch().getQuantityKg() + " kg"
                        + "\nDetected: " + a.getDetected().format(BatchEvent.FMT)
                        + "\nStatus: " + (a.getStatus() == Alert.Status.PENDING ? "Pending" : a.getResolution())
                        + "\nAction: Review & recheck freshness",
                "Alert Details", JOptionPane.INFORMATION_MESSAGE);
        new BatchDetailsFrame(ctx, a.getBatch(), () -> { refresh(); onChange.run(); }).setVisible(true);
    }

    private void resolve(boolean rescued) {
        if (tabs.getSelectedIndex() != 0) { UI.error(this, "Only pending alerts can be resolved."); return; }
        Alert a = selected();
        if (a == null) return;
        ctx.alerts.resolve(a, rescued);
        refresh();
        onChange.run();
    }

    private void refresh() {
        pendingModel.clear(); resolvedModel.clear();
        for (int i = 0; i < ctx.alerts.getPending().size(); i++) pendingModel.addElement(ctx.alerts.getPending().get(i));
        for (int i = 0; i < ctx.alerts.getResolved().size(); i++) resolvedModel.addElement(ctx.alerts.getResolved().get(i));
        tabs.setTitleAt(0, "Pending (" + pendingModel.size() + ")");
        tabs.setTitleAt(1, "Resolved (" + resolvedModel.size() + ")");
    }
}
