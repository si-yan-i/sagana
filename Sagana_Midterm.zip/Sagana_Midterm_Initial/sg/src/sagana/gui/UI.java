package sagana.gui;

import sagana.model.Batch;
import javax.swing.*;
import java.awt.*;

/** Shared styling helpers. */
final class UI {
    static final Color GREEN = new Color(46, 125, 50);
    static final Color LIGHT = new Color(241, 248, 233);
    static final Color ORANGE = new Color(239, 108, 0);
    static final Color RED = new Color(198, 40, 40);
    static final Color AMBER = new Color(249, 168, 37);

    private UI() {}

    static JLabel title(String text) {
        JLabel l = new JLabel(text);
        l.setFont(l.getFont().deriveFont(Font.BOLD, 20f));
        l.setForeground(GREEN);
        l.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        return l;
    }

    static JButton button(String text) {
        JButton b = new JButton(text);
        b.setBackground(GREEN);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        return b;
    }

    static Color statusColor(Batch.Freshness f) {
        switch (f) {
            case FRESH: return GREEN;
            case SAFE_FOR_SALE: return AMBER;
            case NEAR_SPOILAGE: return ORANGE;
            default: return RED;
        }
    }

    static void error(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
