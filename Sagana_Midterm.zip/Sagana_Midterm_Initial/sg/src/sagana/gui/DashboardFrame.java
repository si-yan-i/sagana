package sagana.gui;

import sagana.AppContext;
import sagana.ds.ResizableArray;
import sagana.model.Batch;
import javax.swing.*;
import java.awt.*;

public class DashboardFrame extends JFrame {
    private final AppContext ctx;
    private final JLabel[] counts = new JLabel[4];
    private final JLabel kg = new JLabel(), meals = new JLabel(), waste = new JLabel(),
            tx = new JLabel(), pending = new JLabel();

    public DashboardFrame(AppContext ctx) {
        super("SAGANA - Dashboard");
        this.ctx = ctx;
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(460, 620);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UI.LIGHT);
        JPanel header = new JPanel(new GridLayout(2, 1));
        header.setOpaque(false);
        header.add(UI.title("Good Day, Admin!"));
        JLabel sub = new JLabel("  Here's the latest update of your batches.");
        header.add(sub);
        root.add(header, BorderLayout.NORTH);

        JPanel center = new JPanel();
        center.setOpaque(false);
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));

        JPanel overview = new JPanel(new GridLayout(2, 2, 8, 8));
        overview.setBorder(BorderFactory.createTitledBorder("Freshness Overview"));
        Batch.Freshness[] fs = Batch.Freshness.values();
        for (int i = 0; i < 4; i++) {
            counts[i] = new JLabel("", SwingConstants.CENTER);
            counts[i].setOpaque(true);
            counts[i].setBackground(UI.statusColor(fs[i]));
            counts[i].setForeground(Color.WHITE);
            counts[i].setFont(counts[i].getFont().deriveFont(Font.BOLD, 14f));
            overview.add(counts[i]);
        }
        center.add(overview);

        JPanel metrics = new JPanel(new GridLayout(5, 1, 4, 4));
        metrics.setBorder(BorderFactory.createTitledBorder("Key Metrics"));
        metrics.add(kg); metrics.add(meals); metrics.add(waste); metrics.add(tx); metrics.add(pending);
        center.add(metrics);

        JPanel nav = new JPanel(new GridLayout(3, 1, 6, 6));
        nav.setBorder(BorderFactory.createTitledBorder("Modules"));
        JButton farm = UI.button("Farm & Harvest");
        JButton route = UI.button("Route Planning");
        JButton alerts = UI.button("Queue Alerts");
        farm.addActionListener(e -> new FarmHarvestFrame(ctx, this::refresh).setVisible(true));
        route.addActionListener(e -> new RoutePlanningFrame(ctx).setVisible(true));
        alerts.addActionListener(e -> new AlertQueueFrame(ctx, this::refresh).setVisible(true));
        nav.add(farm); nav.add(route); nav.add(alerts);
        center.add(nav);
        root.add(center, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new GridLayout(1, 4, 4, 4));
        JButton bDash = new JButton("Dashboard"), bNotif = new JButton("Notification"),
                bSave = new JButton("Saved Data"), bOut = new JButton("Logout");
        bDash.addActionListener(e -> refresh());
        bNotif.addActionListener(e -> new AlertQueueFrame(ctx, this::refresh).setVisible(true));
        bSave.addActionListener(e -> {
            ctx.save();
            JOptionPane.showMessageDialog(this, "Data saved to sagana_data.ser");
        });
        bOut.addActionListener(e -> {
            ctx.save();
            for (Window w : Window.getWindows()) if (w != this) w.dispose();
            new LoginFrame(ctx).setVisible(true);
            dispose();
        });
        bottom.add(bDash); bottom.add(bNotif); bottom.add(bSave); bottom.add(bOut);
        root.add(bottom, BorderLayout.SOUTH);

        add(root);
        // Periodic freshness recheck for real-time countdowns
        new Timer(60_000, e -> refresh()).start();
        refresh();
    }

    void refresh() {
        ctx.harvest.recheckAll();
        ResizableArray<Batch> bs = ctx.harvest.getBatches();
        int[] c = new int[4];
        double spoiledKg = 0;
        for (int i = 0; i < bs.size(); i++) {
            Batch b = bs.get(i);
            c[b.getFreshness().ordinal()]++;
            if (b.getFreshness() == Batch.Freshness.SPOILED) spoiledKg += b.getQuantityKg();
            ctx.alerts.flagIfNeeded(b);
        }
        Batch.Freshness[] fs = Batch.Freshness.values();
        for (int i = 0; i < 4; i++) counts[i].setText(fs[i].label() + ": " + c[i]);
        double rescued = ctx.alerts.kgRescued();
        double atRisk = rescued + spoiledKg;
        kg.setText("  Kilograms Rescued: " + String.format("%.1f kg", rescued));
        meals.setText("  Meals Recovered: " + ctx.alerts.mealsRecovered());
        waste.setText("  Waste Rescued: " + String.format("%.1f %%", atRisk == 0 ? 0 : rescued / atRisk * 100));
        tx.setText("  Transactions: " + ctx.alerts.transactions());
        pending.setText("  Pending Alerts: " + ctx.alerts.getPending().size());
    }
}
