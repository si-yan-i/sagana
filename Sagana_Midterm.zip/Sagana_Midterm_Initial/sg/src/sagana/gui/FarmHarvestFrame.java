package sagana.gui;

import sagana.AppContext;
import sagana.model.Batch;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class FarmHarvestFrame extends JFrame {
    private static final String[] CATEGORIES = {"Vegetable", "Fruit", "Root Crop", "Leafy Green"};
    private final AppContext ctx;
    private final Runnable onChange;
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Crop", "Category", "Weight (kg)", "Remaining (hrs)", "Status"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JTextField search = new JTextField(12);
    private final JComboBox<String> filter = new JComboBox<>();

    public FarmHarvestFrame(AppContext ctx, Runnable onChange) {
        super("SAGANA - Farm & Harvest");
        this.ctx = ctx; this.onChange = onChange;
        setSize(700, 450);
        setLocationRelativeTo(null);

        filter.addItem("All");
        for (Batch.Freshness f : Batch.Freshness.values()) filter.addItem(f.label());

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(UI.title("FARM & HARVEST"));
        top.add(new JLabel("Search:")); top.add(search);
        top.add(new JLabel("Status:")); top.add(filter);
        search.addActionListener(e -> reload());
        search.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { reload(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { reload(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { reload(); }
        });
        filter.addActionListener(e -> reload());

        JPanel buttons = new JPanel();
        JButton reg = UI.button("Register Harvest"), view = UI.button("View Batch Details"), del = UI.button("Remove Batch");
        reg.addActionListener(e -> register());
        view.addActionListener(e -> { Batch b = selected(); if (b != null) new BatchDetailsFrame(ctx, b, this::changed).setVisible(true); });
        del.addActionListener(e -> remove());
        buttons.add(reg); buttons.add(view); buttons.add(del);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);
        reload();
    }

    private void changed() { reload(); onChange.run(); }

    private void reload() {
        ctx.harvest.recheckAll();
        model.setRowCount(0);
        String q = search.getText().trim().toLowerCase();
        String f = (String) filter.getSelectedItem();
        LocalDateTime now = LocalDateTime.now();
        for (int i = 0; i < ctx.harvest.getBatches().size(); i++) {
            Batch b = ctx.harvest.getBatches().get(i);
            if (!q.isEmpty() && !(b.getCrop().toLowerCase().contains(q) || b.getId().toLowerCase().contains(q)
                    || b.getFarm().toLowerCase().contains(q))) continue;
            if (!"All".equals(f) && !b.getFreshness().label().equals(f)) continue;
            model.addRow(new Object[]{"#" + b.getId(), b.getCrop(), b.getCategory(), b.getQuantityKg(),
                    String.format("%.0f", b.remainingShelfLife(now)), b.getFreshness().label()});
        }
    }

    private Batch selected() {
        int row = table.getSelectedRow();
        if (row < 0) { UI.error(this, "Select a batch first."); return null; }
        String id = ((String) model.getValueAt(row, 0)).substring(1);
        for (int i = 0; i < ctx.harvest.getBatches().size(); i++)
            if (ctx.harvest.getBatches().get(i).getId().equals(id)) return ctx.harvest.getBatches().get(i);
        return null;
    }

    private void register() {
        JTextField crop = new JTextField(), farm = new JTextField("Fresh Start Organic Farm"),
                kg = new JTextField(), shelf = new JTextField("72"),
                date = new JTextField(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
        JComboBox<String> cat = new JComboBox<>(CATEGORIES);
        Object[] form = {"Crop type:", crop, "Category:", cat, "Farm:", farm, "Quantity (kg):", kg,
                "Shelf life (hrs):", shelf, "Harvest date (yyyy-MM-dd HH:mm):", date};
        if (JOptionPane.showConfirmDialog(this, form, "Register Harvest", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;
        try {
            ctx.harvest.submitHarvest(crop.getText(), (String) cat.getSelectedItem(), farm.getText(),
                    Double.parseDouble(kg.getText().trim()), Integer.parseInt(shelf.getText().trim()),
                    LocalDateTime.parse(date.getText().trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
            int n = ctx.harvest.processQueue();
            JOptionPane.showMessageDialog(this, n + " batch(es) processed from the registration queue.");
            changed();
        } catch (NumberFormatException ex) {
            UI.error(this, "Quantity and shelf life must be numbers.");
        } catch (java.time.format.DateTimeParseException ex) {
            UI.error(this, "Invalid date format. Use yyyy-MM-dd HH:mm.");
        } catch (IllegalArgumentException ex) {
            UI.error(this, ex.getMessage());
        }
    }

    private void remove() {
        Batch b = selected();
        if (b == null) return;
        if (JOptionPane.showConfirmDialog(this, "Remove batch #" + b.getId() + "?", "Confirm",
                JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        ctx.alerts.removeAlertsFor(b);
        ctx.harvest.removeBatch(b);
        changed();
    }
}
