package sagana;

import sagana.gui.LoginFrame;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        AppContext ctx = new AppContext();
        Runtime.getRuntime().addShutdownHook(new Thread(ctx::save));
        SwingUtilities.invokeLater(() -> new LoginFrame(ctx).setVisible(true));
    }
}
