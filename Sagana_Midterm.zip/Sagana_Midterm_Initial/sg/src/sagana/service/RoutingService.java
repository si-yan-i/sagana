package sagana.service;

import sagana.ds.ResizableArray;
import sagana.model.RouteEdge;
import sagana.model.RouteNode;
import java.util.*;

/** Weighted road graph with Dijkstra (shortest travel time) and Yen's k-shortest paths. */
public class RoutingService {
    public static class Path {
        public final List<RouteNode> nodes;
        public final List<RouteEdge> edges;
        public final double hours, km;
        Path(List<RouteNode> nodes, List<RouteEdge> edges) {
            this.nodes = nodes; this.edges = edges;
            double h = 0, k = 0;
            for (RouteEdge e : edges) { h += e.getHours(); k += e.getDistanceKm(); }
            hours = h; km = k;
        }
        @Override public String toString() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < nodes.size(); i++) { if (i > 0) sb.append(" -> "); sb.append(nodes.get(i).getName()); }
            return sb + String.format("   [%.1f km / %.2f h]", km, hours);
        }
    }

    private final ResizableArray<RouteNode> nodes;
    private final ResizableArray<RouteEdge> edges;

    public RoutingService(ResizableArray<RouteNode> nodes, ResizableArray<RouteEdge> edges) {
        this.nodes = nodes; this.edges = edges;
    }

    public ResizableArray<RouteNode> getNodes() { return nodes; }
    public ResizableArray<RouteEdge> getEdges() { return edges; }

    public RouteNode find(String name) {
        for (int i = 0; i < nodes.size(); i++) if (nodes.get(i).getName().equals(name)) return nodes.get(i);
        return null;
    }

    /** Average road speed used to estimate travel time when the user does not enter one. */
    public static final double AVG_SPEED_KMH = 35;

    public static double estimateHours(double km) {
        return Math.max(0.01, Math.round(km / AVG_SPEED_KMH * 100) / 100.0);
    }

    /** Returns the road directly joining a and b (either direction), or null. */
    public RouteEdge findEdge(RouteNode a, RouteNode b) {
        for (int i = 0; i < edges.size(); i++) {
            RouteEdge e = edges.get(i);
            if ((e.getFrom() == a && e.getTo() == b) || (e.getFrom() == b && e.getTo() == a)) return e;
        }
        return null;
    }

    private static void checkRoad(double km, double hours) {
        if (!Double.isFinite(km) || km <= 0) throw new IllegalArgumentException("Distance must be greater than 0 km.");
        if (!Double.isFinite(hours) || hours <= 0) throw new IllegalArgumentException("Travel time must be greater than 0 hours.");
    }

    /** Adds a road between two existing locations. */
    public RouteEdge addRoad(RouteNode a, RouteNode b, double km, double hours) {
        if (a == null || b == null) throw new IllegalArgumentException("Select both locations.");
        if (a == b) throw new IllegalArgumentException("A road must join two different locations.");
        checkRoad(km, hours);
        if (findEdge(a, b) != null) throw new IllegalArgumentException("A road between these locations already exists.");
        RouteEdge e = new RouteEdge(a, b, km, hours);
        edges.add(e);
        return e;
    }

    /**
     * Adds a new Farm, Hub or Market and joins it to the network with one road.
     * Everything is validated first, so a failed add never leaves a half-created location.
     * The map position is chosen automatically next to the location it connects to.
     */
    public RouteNode addLocation(String name, RouteNode.Kind kind, RouteNode connectTo, double km, double hours) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Location name is required.");
        if (kind == null) throw new IllegalArgumentException("Select a location type (Farm, Hub or Market).");
        name = name.trim();
        for (int i = 0; i < nodes.size(); i++)
            if (nodes.get(i).getName().equalsIgnoreCase(name))
                throw new IllegalArgumentException("A location named \"" + name + "\" already exists.");
        if (connectTo != null) checkRoad(km, hours);
        int[] pos = suggestPosition(connectTo);
        RouteNode n = new RouteNode(name, kind, pos[0], pos[1]);
        nodes.add(n);
        if (connectTo != null) edges.add(new RouteEdge(connectTo, n, km, hours));
        return n;
    }

    /**
     * Finds a spot near 'near' (or the centre) where the new node and its text label will not sit on
     * top of an existing one. A spot is "free" when it is at least 190 px away horizontally or 45 px
     * vertically from every node; if none is free, the least crowded candidate is used.
     */
    int[] suggestPosition(RouteNode near) {
        int cx = near == null ? 350 : near.getX(), cy = near == null ? 230 : near.getY();
        int[] best = null;
        double bestScore = -1;
        for (int r = 100; r <= 340; r += 60) {
            for (int deg = 0; deg < 360; deg += 24) {
                int x = clamp(cx + (int) Math.round(r * Math.cos(Math.toRadians(deg))), 30, 700);
                int y = clamp(cy + (int) Math.round(r * Math.sin(Math.toRadians(deg))), 30, 390);
                double score = Double.MAX_VALUE;
                for (int i = 0; i < nodes.size(); i++) {
                    double dx = Math.abs(nodes.get(i).getX() - x) / 190.0, dy = Math.abs(nodes.get(i).getY() - y) / 45.0;
                    score = Math.min(score, Math.max(dx, dy));
                }
                if (score >= 1) return new int[]{x, y};
                if (score > bestScore) { bestScore = score; best = new int[]{x, y}; }
            }
        }
        return best;
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    public List<RouteNode> nodesOfKind(RouteNode.Kind k) {
        List<RouteNode> out = new ArrayList<>();
        for (int i = 0; i < nodes.size(); i++) if (nodes.get(i).getKind() == k) out.add(nodes.get(i));
        return out;
    }

    /** Dijkstra on travel hours, ignoring removed edges/nodes (used by Yen's). */
    public Path dijkstra(RouteNode src, RouteNode dst, Set<RouteEdge> bannedEdges, Set<RouteNode> bannedNodes) {
        Map<RouteNode, Double> dist = new HashMap<>();
        Map<RouteNode, RouteEdge> via = new HashMap<>();
        PriorityQueue<Object[]> pq = new PriorityQueue<>(Comparator.comparingDouble(a -> (Double) a[1]));
        dist.put(src, 0.0);
        pq.add(new Object[]{src, 0.0});
        while (!pq.isEmpty()) {
            Object[] top = pq.poll();
            RouteNode u = (RouteNode) top[0];
            double d = (Double) top[1];
            if (d > dist.getOrDefault(u, Double.MAX_VALUE)) continue;
            if (u == dst) break;
            for (int i = 0; i < edges.size(); i++) {
                RouteEdge e = edges.get(i);
                if (e.getFrom() != u && e.getTo() != u) continue;
                if (bannedEdges.contains(e)) continue;
                RouteNode v = e.other(u);
                if (bannedNodes.contains(v)) continue;
                double nd = d + e.getHours();
                if (nd < dist.getOrDefault(v, Double.MAX_VALUE)) {
                    dist.put(v, nd); via.put(v, e); pq.add(new Object[]{v, nd});
                }
            }
        }
        if (!dist.containsKey(dst)) return null;
        LinkedList<RouteNode> pn = new LinkedList<>();
        LinkedList<RouteEdge> pe = new LinkedList<>();
        RouteNode cur = dst;
        pn.addFirst(cur);
        while (cur != src) {
            RouteEdge e = via.get(cur);
            pe.addFirst(e);
            cur = e.other(cur);
            pn.addFirst(cur);
        }
        return new Path(new ArrayList<>(pn), new ArrayList<>(pe));
    }

    public Path shortest(RouteNode src, RouteNode dst) {
        return dijkstra(src, dst, new HashSet<>(), new HashSet<>());
    }

    /** Yen's algorithm: up to k loopless shortest paths, used for alternative routes. */
    public List<Path> kShortest(RouteNode src, RouteNode dst, int k) {
        List<Path> result = new ArrayList<>();
        Path first = shortest(src, dst);
        if (first == null) return result;
        result.add(first);
        List<Path> candidates = new ArrayList<>();
        for (int n = 1; n < k; n++) {
            Path prev = result.get(n - 1);
            for (int i = 0; i < prev.nodes.size() - 1; i++) {
                RouteNode spur = prev.nodes.get(i);
                List<RouteNode> rootNodes = prev.nodes.subList(0, i + 1);
                List<RouteEdge> rootEdges = prev.edges.subList(0, i);
                Set<RouteEdge> banned = new HashSet<>();
                for (Path p : result)
                    if (p.nodes.size() > i && p.nodes.subList(0, i + 1).equals(rootNodes)) banned.add(p.edges.get(i));
                Set<RouteNode> bannedNodes = new HashSet<>(rootNodes);
                bannedNodes.remove(spur);
                Path spurPath = dijkstra(spur, dst, banned, bannedNodes);
                if (spurPath == null) continue;
                List<RouteNode> tn = new ArrayList<>(rootNodes);
                tn.addAll(spurPath.nodes.subList(1, spurPath.nodes.size()));
                List<RouteEdge> te = new ArrayList<>(rootEdges);
                te.addAll(spurPath.edges);
                Path total = new Path(tn, te);
                boolean dup = false;
                for (Path c : candidates) if (c.nodes.equals(total.nodes)) dup = true;
                for (Path c : result) if (c.nodes.equals(total.nodes)) dup = true;
                if (!dup) candidates.add(total);
            }
            if (candidates.isEmpty()) break;
            candidates.sort(Comparator.comparingDouble(p -> p.hours));
            result.add(candidates.remove(0));
        }
        return result;
    }

    /** Reports a delay on a road segment (adds hours), which affects the next route calculation. */
    public void reportDelay(RouteEdge e, double extraHours) { e.setHours(e.getHours() + extraHours); }
}
