package sagana.service;

import sagana.ds.CustomQueue;
import sagana.ds.ResizableArray;
import sagana.model.*;
import java.io.*;

/** Saves and loads all application data to a local file (sagana_data.ser). */
public class PersistenceService {
    public static final String FILE = "sagana_data.ser";

    public static class Data implements Serializable {
        public ResizableArray<Batch> batches = new ResizableArray<>();
        public CustomQueue<Alert> pendingAlerts = new CustomQueue<>();
        public ResizableArray<Alert> resolvedAlerts = new ResizableArray<>();
        public ResizableArray<RouteNode> nodes = new ResizableArray<>();
        public ResizableArray<RouteEdge> edges = new ResizableArray<>();
        public int nextBatchId = 1;
    }

    public Data load() {
        File f = new File(FILE);
        if (f.exists()) {
            try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(f))) {
                return (Data) in.readObject();
            } catch (Exception e) {
                System.err.println("Could not read " + FILE + ", starting fresh: " + e.getMessage());
            }
        }
        return seed();
    }

    public void save(Data d) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FILE))) {
            out.writeObject(d);
        } catch (IOException e) {
            System.err.println("Save failed: " + e.getMessage());
        }
    }

    /** Default road network used on first run. */
    private Data seed() {
        Data d = new Data();
        RouteNode farm = new RouteNode("Fresh Start Organic Farm", RouteNode.Kind.FARM, 80, 420);
        RouteNode farm2 = new RouteNode("Green Valley Farm", RouteNode.Kind.FARM, 90, 120);
        RouteNode h1 = new RouteNode("Alijis Junction", RouteNode.Kind.HUB, 260, 330);
        RouteNode h2 = new RouteNode("Mandalagan Hub", RouteNode.Kind.HUB, 280, 150);
        RouteNode h3 = new RouteNode("Tangub Crossing", RouteNode.Kind.HUB, 430, 380);
        RouteNode market = new RouteNode("Libertad Market", RouteNode.Kind.MARKET, 600, 260);
        RouteNode market2 = new RouteNode("Burgos Market", RouteNode.Kind.MARKET, 590, 90);
        for (RouteNode n : new RouteNode[]{farm, farm2, h1, h2, h3, market, market2}) d.nodes.add(n);
        d.edges.add(new RouteEdge(farm, h1, 3.3, 0.1));
        d.edges.add(new RouteEdge(h1, h3, 4.5, 0.1));
        d.edges.add(new RouteEdge(h3, market, 2.2, 0.05));
        d.edges.add(new RouteEdge(h1, h2, 5.0, 0.15));
        d.edges.add(new RouteEdge(h2, market, 6.7, 0.3));
        d.edges.add(new RouteEdge(farm2, h2, 4.1, 0.12));
        d.edges.add(new RouteEdge(h2, market2, 5.4, 0.2));
        d.edges.add(new RouteEdge(market, market2, 3.0, 0.1));
        d.edges.add(new RouteEdge(farm, h3, 9.0, 0.35));
        return d;
    }
}
