package sagana.service;

import sagana.ds.CustomQueue;
import sagana.ds.ResizableArray;
import sagana.model.Alert;
import sagana.model.Batch;
import java.time.LocalDateTime;

/** Near-spoilage alerts: pending alerts in a FIFO queue, resolved alerts in an array. */
public class AlertQueueService {
    public static final double MEALS_PER_KG = 2.5;

    private final CustomQueue<Alert> pending;
    private final ResizableArray<Alert> resolved;

    public AlertQueueService(CustomQueue<Alert> pending, ResizableArray<Alert> resolved) {
        this.pending = pending; this.resolved = resolved;
    }

    /** Flags a batch if it is Near Spoilage and not already pending. Returns true if flagged. */
    public boolean flagIfNeeded(Batch b) {
        if (b.getFreshness() != Batch.Freshness.NEAR_SPOILAGE) return false;
        if (hasPending(b)) return false;
        pending.enqueue(new Alert(b, LocalDateTime.now()));
        return true;
    }

    public boolean hasPending(Batch b) {
        for (int i = 0; i < pending.size(); i++) if (pending.get(i).getBatch() == b) return true;
        return false;
    }

    /** Resolves an alert; rescued = produce handed to a food rescue group. */
    public void resolve(Alert a, boolean rescued) {
        pending.remove(a);
        a.resolve(rescued ? "Rescued" : "Dismissed");
        resolved.add(a);
    }

    public void removeAlertsFor(Batch b) {
        for (int i = pending.size() - 1; i >= 0; i--)
            if (pending.get(i).getBatch() == b) pending.remove(pending.get(i));
    }

    public double kgRescued() {
        double kg = 0;
        for (int i = 0; i < resolved.size(); i++)
            if (resolved.get(i).getResolution().equals("Rescued")) kg += resolved.get(i).getBatch().getQuantityKg();
        return kg;
    }

    public int mealsRecovered() { return (int) (kgRescued() * MEALS_PER_KG); }
    public int transactions() { return resolved.size(); }

    public CustomQueue<Alert> getPending() { return pending; }
    public ResizableArray<Alert> getResolved() { return resolved; }
}
