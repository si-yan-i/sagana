package sagana;

import sagana.service.*;

/** Shared access point for all services. */
public class AppContext {
    public final PersistenceService persistence = new PersistenceService();
    public final PersistenceService.Data data;
    public final HarvestService harvest;
    public final AlertQueueService alerts;
    public final RoutingService routing;

    public AppContext() {
        data = persistence.load();
        harvest = new HarvestService(data.batches, data.nextBatchId);
        alerts = new AlertQueueService(data.pendingAlerts, data.resolvedAlerts);
        routing = new RoutingService(data.nodes, data.edges);
    }

    public void save() {
        data.nextBatchId = harvest.getNextId();
        persistence.save(data);
    }
}
