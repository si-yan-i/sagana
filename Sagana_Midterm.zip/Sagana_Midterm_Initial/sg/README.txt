================================================================
# SAGANA — Java Base Code (Prelim/Midterm DSA Reference)
Delivery Route Optimization and Spoilage Monitoring
Java Swing desktop prototype
================================================================

Contents
  1. Java version
  2. Software requirements
  3. Setup procedure
  4. Run instructions
  5. Sample inputs
  6. Completed functions (midterm scope)
  7. Known limitations

----------------------------------------------------------------
1. JAVA VERSION
----------------------------------------------------------------
Built and tested with JDK 17 (OpenJDK 17.0.18).
The source also compiles cleanly with "javac --release 11", so
JDK 11 or any newer JDK works. No preview or experimental
language features are used.

----------------------------------------------------------------
2. SOFTWARE REQUIREMENTS
----------------------------------------------------------------
- JDK 11 or newer, with javac and java available on the PATH.
- Any desktop OS: Windows 10/11, macOS, or Linux.
- No external libraries, no framework, no database server, and no
  internet connection are required. Everything is plain Java SE:
  Swing for the windows and Java serialization for the saved file.

----------------------------------------------------------------
3. SETUP PROCEDURE
----------------------------------------------------------------
1. Unzip the submission into any folder, for example C:\Sagana
   or ~/Sagana.
2. Check that the folder looks like this:
       Sagana/
         README.txt
         src/
           sagana/
             Main.java
             AppContext.java
             DataStructureTest.java
             ds/        (ResizableArray, SinglyLinkedList, CustomQueue)
             model/     (Batch, BatchEvent, Alert, RouteNode, RouteEdge, User)
             service/   (HarvestService, AlertQueueService,
                         RoutingService, AccountService, PersistenceService)
             gui/       (LoginFrame, DashboardFrame, FarmHarvestFrame,
                         BatchDetailsFrame, AlertQueueFrame, RoutePlanningFrame,
                         AccountsFrame, RescueBoardFrame, UI)
3. Open a terminal (Windows: Command Prompt or PowerShell) and
   move into the Sagana folder:
       cd Sagana
4. Compile all source files into a new "out" folder:

       Linux / macOS:
           javac -d out $(find src -name "*.java")

       Windows (Command Prompt):
           dir /s /b src\*.java > files.txt
           javac -d out @files.txt

   Silence means the build succeeded; the compiled classes are in
   out/sagana.

----------------------------------------------------------------
4. RUN INSTRUCTIONS
----------------------------------------------------------------
Start the application:
       java -cp out sagana.Main

Run the automated checks (21 assertions):
       java -cp out sagana.DataStructureTest
   The last line prints "21 passed, 0 failed".

Sign in with one of the seeded accounts. Each account only sees
the modules its role is allowed to open:

       admin / admin123               Administrator
       producer / producer123         Producer
       transporter / transporter123   Transporter
       rescue / rescue123             Food Rescue Group

Saving data:
   Everything is written to sagana_data.ser in the folder you run
   from when you press "Saved Data", press "Logout", or close the
   window. Delete sagana_data.ser to start again from the seeded
   sample data.

----------------------------------------------------------------
5. SAMPLE INPUTS
----------------------------------------------------------------
Register Harvest  (Farm & Harvest > Register Harvest)
       Crop type:         Lettuce
       Category:          Leafy Green
       Farm:              Fresh Start Organic Farm
       Quantity (kg):     50
       Shelf life (hrs):  48
       Storage temp (C):  10
       Harvest date:      2026-10-27 08:00     (yyyy-MM-dd HH:mm)
   About 40 hours after that time the batch is reported
   "Near Spoilage" and an alert is placed in the queue.
   (10 in the temperature box keeps the estimate equal to the
   midterm rule in section 6; the form starts at 25.)
   Second sample that stays Fresh:
       Tomato / Fruit / 35 kg / shelf life 96 / harvested today

Batch events  (select a batch > View Batch Details)
       Log Dispatched  ->  Log Delayed  ->  Log Arrived
   A batch must be dispatched before a delay or arrival can be
   logged, and a batch that has already arrived cannot be logged
   again.

Road delay  (Route Planning & Navigation > Report Road Delay)
       Road:        Alijis Junction -> Tangub Crossing
       Extra hours: 0.5
   Press "Find Routes" again: the recommended route changes
   because that road now costs more time.

Add a place  (Route Planning > Add Place)
       Name: Banago Depot     Type: HUB     X: 350     Y: 250
Add a road   (Route Planning > Add Road)
       From: Alijis Junction    To: Banago Depot
       Distance (km): 4.0       Travel time (hrs): 0.2

Add an account  (Account Management > Add Account, admin only)
       Username: producer2      Password: farm1234
       Role: Producer           Farm: Green Valley Farm
       Phone: 0917-000-0004

Rescue contact  (Rescue Board > Contact Producer for Pickup)
   Opens an e-mail draft addressed to the producer of the selected
   near-spoilage batch. Nothing is reserved or booked.

Seeded road network (loaded automatically on the first run)
       Farms:    Fresh Start Organic Farm, Green Valley Farm
       Hubs:     Alijis Junction, Mandalagan Hub, Tangub Crossing
       Markets:  Libertad Market, Burgos Market
       9 roads with distance and travel time, for example
       Fresh Start Organic Farm - Alijis Junction: 3.3 km / 0.1 h

----------------------------------------------------------------
6. COMPLETED FUNCTIONS (MIDTERM SCOPE)
----------------------------------------------------------------
Accounts and role-based access
  - Login with username and password; four roles: Administrator,
    Producer, Transporter, Food Rescue Group.
  - The dashboard lists only the modules the signed-in role may
    open, and the pending-alert count is limited to the batches
    that role is allowed to see.
  - Administrator: Account Management, Farm & Harvest, Route
    Planning & Navigation, Queue Alerts (Recovery), and Rescue
    Board & Reports.
  - Producer: Farm & Harvest only, showing only their own farm's
    batches; the farm name is locked to the account.
  - Transporter: Route Planning & Navigation and Deliveries &
    Delays (dispatch, delay and arrival logging).
  - Food Rescue Group: Rescue Board, view only - batch freshness,
    near-spoilage batches with the producer's phone and e-mail,
    and the rescued-food report. Recovery is by direct contact;
    there is no reservation system.
  - Account Management: add an account (password at least 6
    characters, producers must have a farm name, usernames must
    be unique) and remove an account; the last administrator
    cannot be removed.

Harvest registration and freshness tracking
  - Harvest requests are held in a first-in-first-out registration
    queue and processed in arrival order; each batch receives an
    ID (B0001, B0002, ...).
  - Input validation: crop and farm are required, quantity and
    shelf life must be greater than zero, and the harvest date
    cannot be in the future.
  - Rule-based freshness score:
        elapsed = hours since harvest + 6 hours per logged delay
        p = min(1, elapsed / shelf life)
        p < 0.40        Fresh
        0.40 - 0.69     Safe for Sale
        0.70 - 0.99     Near Spoilage
        1.00            Spoiled
  - Event history per batch (Harvested, Dispatched, Delayed,
    Arrived) with timestamps, plus the hours of shelf life
    remaining.
  - Batch list can be searched by crop and filtered by status.

Route planning and navigation
  - Weighted road map: places are FARM, HUB or MARKET nodes and
    roads carry distance (km) and travel time (hrs).
  - Dijkstra's algorithm finds the fastest route on travel time;
    Yen's k-shortest algorithm (k = 3) supplies alternative
    routes.
  - Map view with zoom controls, and a Network view listing every
    place and road. "Add Place" and "Add Road" extend the map, and
    a new farm or market appears in the From / To pickers.
  - "Report Road Delay" adds hours to a road, and the next route
    calculation avoids it.

Spoilage alerts and food recovery
  - A batch that reaches Near Spoilage is queued automatically as
    a pending alert, with no duplicate while it is still pending.
  - The administrator resolves an alert as "Rescued" (produce
    handed to a food rescue group) or "Dismissed".
  - Rescue-board report: kilograms rescued, meals recovered
    (2.5 meals per kg), waste-rescued percentage, and the number
    of transactions.

Custom data structures and persistence
  - ResizableArray<T> (dynamic array), SinglyLinkedList<T> (batch
    event history) and CustomQueue<T> (registration and alert
    queues) are written from scratch and used by the models and
    services.
  - All data is saved and reloaded through Java serialization in
    sagana_data.ser; the road network and the four sample accounts
    are created on the first run.

Automated checks
  - sagana.DataStructureTest runs 21 assertions covering the
    three data structures, freshness classification, alert
    queueing and rescue totals, Dijkstra / Yen's / delay
    recalculation, and the role permissions and account rules.
    All 21 pass on this build.

----------------------------------------------------------------
7. KNOWN LIMITATIONS
----------------------------------------------------------------
- Local prototype only. Accounts and passwords live in the local
  data file, not in a secured database; roles gate the screens but
  are not backed by real authentication.
- Freshness is an estimate from elapsed time and logged delays,
  not a measured value. Every delay is counted as a fixed 6 hours
  because the app does not record how long a delay actually
  lasted.
- The harvest form still asks for a storage temperature, and this
  build still applies it to the decay estimate. Storage
  temperature is outside the midterm scope above and is scheduled
  to be removed from the form and the formula.
- The 6-hour delay penalty, the 0.40 / 0.70 / 1.00 thresholds and
  the 2.5 meals per kg figure are fixed in code and cannot be
  changed from the interface.
- Recovery is contact-based only: there is no reservation, no
  pickup scheduling and no confirmation from the producer. The
  contact button needs a mail client configured on the machine;
  otherwise the message is only shown on screen.
- The map is drawn from manually entered coordinates, so distances
  are sample values and not taken from a real mapping service.
- Reports are on screen only; there is no export to CSV or PDF and
  no historical charts.
- Producer, transporter and rescue accounts are created by the
  administrator; there is no self-signup and no password recovery.
- The saved file is tied to this build's class definitions, so a
  sagana_data.ser written by an earlier build cannot be read here;
  the app then starts fresh from the seeded sample data.
- Only one user works on the file at a time; there is no
  multi-machine or concurrent use.