package com.sagana.test;

import com.sagana.datastructures.CustomQueue;
import com.sagana.datastructures.ResizableArray;
import com.sagana.datastructures.SinglyLinkedList;

/**
 * Manual (assertion-based) tests for the three custom linear data structures
 * used in the Prelim build. Run directly (no JUnit dependency required) to
 * verify correctness of the resizable array, linked list, and queue before
 * they are wired into the UI/service layers.
 */
public class DataStructureTest {

    private static int passed = 0;
    private static int failed = 0;

    public static void main(String[] args) {
        testResizableArray();
        testSinglyLinkedList();
        testCustomQueue();

        System.out.println("\n=== Test Summary: " + passed + " passed, " + failed + " failed ===");
    }

    private static void testResizableArray() {
        System.out.println("--- ResizableArray ---");
        ResizableArray<String> array = new ResizableArray<>(2); // small capacity to force a resize

        check("initial size is 0", array.size() == 0);
        check("initial capacity is 2", array.capacity() == 2);

        array.add("Tomato");
        array.add("Mango");
        check("size is 2 after two adds", array.size() == 2);
        check("capacity still 2 before resize trigger", array.capacity() == 2);

        array.add("Onion"); // this add should trigger a resize
        check("size is 3 after third add", array.size() == 3);
        check("capacity doubled to 4 after resize", array.capacity() == 4);
        check("get(0) returns Tomato", array.get(0).equals("Tomato"));
        check("get(2) returns Onion", array.get(2).equals("Onion"));

        check("indexOf Mango is 1", array.indexOf("Mango") == 1);
        check("contains Onion is true", array.contains("Onion"));

        array.removeAt(1); // remove Mango
        check("size is 2 after removeAt", array.size() == 2);
        check("get(1) is now Onion after shift", array.get(1).equals("Onion"));

        boolean removed = array.remove("Tomato");
        check("remove(Tomato) returns true", removed);
        check("size is 1 after remove", array.size() == 1);
    }

    private static void testSinglyLinkedList() {
        System.out.println("--- SinglyLinkedList ---");
        SinglyLinkedList<String> list = new SinglyLinkedList<>();

        check("initial size is 0", list.size() == 0);
        check("initial isEmpty is true", list.isEmpty());

        list.append("Harvested");
        list.append("Dispatched");
        list.append("Delayed");

        check("size is 3 after three appends", list.size() == 3);
        check("getFirst returns Harvested", list.getFirst().equals("Harvested"));
        check("getLast returns Delayed", list.getLast().equals("Delayed"));
        check("contains Dispatched is true", list.contains("Dispatched"));
        check("contains Arrived is false", !list.contains("Arrived"));

        StringBuilder order = new StringBuilder();
        for (String event : list) {
            order.append(event).append(",");
        }
        check("traversal preserves append order",
                order.toString().equals("Harvested,Dispatched,Delayed,"));
    }

    private static void testCustomQueue() {
        System.out.println("--- CustomQueue ---");
        CustomQueue<String> queue = new CustomQueue<>();

        check("initial isEmpty is true", queue.isEmpty());

        queue.enqueue("B0001");
        queue.enqueue("B0002");
        queue.enqueue("B0003");

        check("size is 3 after three enqueues", queue.size() == 3);
        check("peek returns B0001 (FIFO front)", queue.peek().equals("B0001"));

        String first = queue.dequeue();
        check("first dequeue returns B0001", first.equals("B0001"));
        check("size is 2 after dequeue", queue.size() == 2);
        check("peek now returns B0002", queue.peek().equals("B0002"));

        queue.dequeue();
        queue.dequeue();
        check("isEmpty is true after all dequeues", queue.isEmpty());
    }

    private static void check(String description, boolean condition) {
        if (condition) {
            passed++;
            System.out.println("  [PASS] " + description);
        } else {
            failed++;
            System.out.println("  [FAIL] " + description);
        }
    }
}
