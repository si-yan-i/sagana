package com.sagana.model;

import com.sagana.datastructures.SinglyLinkedList;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * Represents a single registered quantity of harvested produce, tracked as
 * one unit from harvest to delivery (see Definition of Technical Terms,
 * Chapter 1). Each Batch owns its own chronological event history, stored in
 * a custom SinglyLinkedList, so no hash map is needed to associate the two —
 * consistent with the Prelim Term's linear-structures-only scope.
 */
public class Batch {

    private final String batchId;
    private final String farmName;
    private final String cropType;   // e.g. Tomato, Mango, Onion
    private final String category;   // e.g. Vegetable, Fruit, Grain
    private final LocalDateTime harvestDate;
    private final double quantityKg;
    private final int shelfLifeHours; // expected shelf life at harvest

    private final SinglyLinkedList<BatchEvent> eventHistory = new SinglyLinkedList<>();

    public Batch(String batchId, String farmName, String cropType, String category,
                 LocalDateTime harvestDate, double quantityKg, int shelfLifeHours) {
        this.batchId = batchId;
        this.farmName = farmName;
        this.cropType = cropType;
        this.category = category;
        this.harvestDate = harvestDate;
        this.quantityKg = quantityKg;
        this.shelfLifeHours = shelfLifeHours;

        // The batch always begins its life with a HARVESTED event.
        eventHistory.append(new BatchEvent(EventType.HARVESTED, harvestDate, "Batch registered"));
    }

    // --- Getters ---
    public String getBatchId() { return batchId; }
    public String getFarmName() { return farmName; }
    public String getCropType() { return cropType; }
    public String getCategory() { return category; }
    public LocalDateTime getHarvestDate() { return harvestDate; }
    public double getQuantityKg() { return quantityKg; }
    public int getShelfLifeHours() { return shelfLifeHours; }
    public SinglyLinkedList<BatchEvent> getEventHistory() { return eventHistory; }

    /** Appends a new event to this batch's history (e.g. Dispatched, Delayed, Arrived). */
    public void logEvent(EventType type, String note) {
        eventHistory.append(new BatchEvent(type, LocalDateTime.now(), note));
    }

    /** Hours elapsed since harvest, computed live rather than stored, so it is always current. */
    public double hoursSinceHarvest() {
        return ChronoUnit.MINUTES.between(harvestDate, LocalDateTime.now()) / 60.0;
    }

    /** Fraction (0.0 - 1.0+) of shelf life consumed so far. */
    public double shelfLifeUsedRatio() {
        if (shelfLifeHours <= 0) return 1.0;
        return hoursSinceHarvest() / shelfLifeHours;
    }

    /**
     * Rule-based freshness classification for the Prelim build, based purely on
     * elapsed time versus shelf life. The Final Term extends this into a
     * multi-variable weighted spoilage-probability score (travel time, storage
     * temperature, handling duration) as described in the Proposed Data
     * Structures and Algorithms section.
     */
    public FreshnessStatus computeFreshnessStatus() {
        double ratio = shelfLifeUsedRatio();
        if (ratio < 0.50) return FreshnessStatus.FRESH;
        if (ratio < 0.75) return FreshnessStatus.SAFE_FOR_SALE;
        if (ratio < 1.00) return FreshnessStatus.NEAR_SPOILAGE;
        return FreshnessStatus.SPOILED;
    }

    @Override
    public String toString() {
        return String.format("[%s] %s (%s) — %.1fkg — %s",
                batchId, cropType, category, quantityKg, computeFreshnessStatus());
    }
}
