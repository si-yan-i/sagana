package com.sagana.model;

/**
 * Represents a batch's freshness classification, derived from how much of
 * its shelf life has elapsed relative to harvest date.
 */
public enum FreshnessStatus {
    FRESH,
    SAFE_FOR_SALE,
    NEAR_SPOILAGE,
    SPOILED
}
