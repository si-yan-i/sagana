package com.sagana.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * A single logged event in a batch's chronological history (e.g. Harvested,
 * Dispatched, Delayed, Arrived). Implemented as a Java record since it is an
 * immutable value once logged — an event that happened does not change.
 *
 * Stored as nodes in a SinglyLinkedList (see datastructures package) so that
 * the Batch Details freshness timeline can be appended to and traversed in
 * chronological order.
 */
public record BatchEvent(EventType type, LocalDateTime timestamp, String note) {

    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("MMM d, yyyy h:mm a");

    @Override
    public String toString() {
        String base = type + " — " + timestamp.format(FORMAT);
        return (note == null || note.isBlank()) ? base : base + " (" + note + ")";
    }
}
