package com.sagana.model;

/** Types of events logged against a batch's chronological history. */
public enum EventType {
    HARVESTED,
    DISPATCHED,
    DELAYED,
    ARRIVED
}
