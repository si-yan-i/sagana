package com.sagana.util;

/** Generates simple, sequential, human-readable batch IDs (e.g. B0001, B0002). */
public final class IdGenerator {

    private static int counter = 0;

    private IdGenerator() { }

    public static synchronized String nextBatchId() {
        counter++;
        return Constants.BATCH_ID_PREFIX + String.format("%04d", counter);
    }
}
