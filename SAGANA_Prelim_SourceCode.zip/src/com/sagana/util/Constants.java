package com.sagana.util;

/** Central location for named constants, avoiding magic numbers/literals across the codebase. */
public final class Constants {

    private Constants() { } // prevent instantiation

    // Demo admin credentials for the Prelim Login screen.
    public static final String ADMIN_USERNAME = "admin";
    public static final String ADMIN_PASSWORD = "sagana2026";

    // Default resizable array starting capacity for a new farmer's batch list.
    public static final int DEFAULT_BATCH_CAPACITY = 4;

    // Batch ID prefix used by IdGenerator.
    public static final String BATCH_ID_PREFIX = "B";
}
