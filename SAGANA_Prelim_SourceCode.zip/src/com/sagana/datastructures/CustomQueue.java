package com.sagana.datastructures;

import java.util.NoSuchElementException;

/**
 * Custom generic first-in-first-out (FIFO) queue, implemented using linked
 * nodes so enqueue and dequeue both run in O(1) without shifting elements.
 *
 * Backs the Near-Spoilage alert pipeline (Chapter 1, Section 5.4): batches
 * are enqueued the moment they are flagged Near Spoilage, and processed
 * (dequeued) in the exact order they were flagged.
 *
 * Complexity:
 *  - enqueue: O(1)
 *  - dequeue: O(1)
 *  - peek:    O(1)
 *
 * @param <T> the type of element stored
 */
public class CustomQueue<T> {

    private static class Node<T> {
        T value;
        Node<T> next;

        Node(T value) {
            this.value = value;
        }
    }

    private Node<T> front;
    private Node<T> rear;
    private int size;

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    /** Adds an element to the rear of the queue. O(1). */
    public void enqueue(T value) {
        Node<T> newNode = new Node<>(value);
        if (rear == null) {
            front = newNode;
            rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
        size++;
    }

    /** Removes and returns the element at the front of the queue. O(1). */
    public T dequeue() {
        if (front == null) throw new NoSuchElementException("Queue is empty");
        T value = front.value;
        front = front.next;
        if (front == null) rear = null;
        size--;
        return value;
    }

    /** Returns (without removing) the element at the front of the queue. O(1). */
    public T peek() {
        if (front == null) throw new NoSuchElementException("Queue is empty");
        return front.value;
    }
}
