package com.sagana.datastructures;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Custom generic singly linked list — stores elements as nodes connected by
 * references, appended at the tail.
 *
 * Backs each Batch's chronological event history (Chapter 1, Section 5.2),
 * since the number of events per batch is unknown in advance and events are
 * only ever added in order — a natural fit for a linked list over an array.
 *
 * Complexity:
 *  - append (tail-pointer):  O(1)
 *  - traversal / search:     O(n)
 *
 * @param <T> the type of element stored
 */
public class SinglyLinkedList<T> implements Iterable<T> {

    /** A single node in the list, holding a value and a reference to the next node. */
    private static class Node<T> {
        T value;
        Node<T> next;

        Node(T value) {
            this.value = value;
        }
    }

    private Node<T> head;
    private Node<T> tail; // tail pointer keeps append at O(1)
    private int size;

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    /** Appends a new value to the end of the list. O(1) via the tail pointer. */
    public void append(T value) {
        Node<T> newNode = new Node<>(value);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            tail = newNode;
        }
        size++;
    }

    /** Returns the first element, or throws if the list is empty. O(1). */
    public T getFirst() {
        if (head == null) throw new NoSuchElementException("List is empty");
        return head.value;
    }

    /** Returns the last element, or throws if the list is empty. O(1) via tail pointer. */
    public T getLast() {
        if (tail == null) throw new NoSuchElementException("List is empty");
        return tail.value;
    }

    /** Linear search for whether a value exists in the list. O(n). */
    public boolean contains(T value) {
        for (T item : this) {
            if (item == null ? value == null : item.equals(value)) {
                return true;
            }
        }
        return false;
    }

    /** Returns all elements as a plain Java array, in chronological (append) order. O(n). */
    @SuppressWarnings("unchecked")
    public Object[] toArray() {
        Object[] result = new Object[size];
        int i = 0;
        for (T item : this) {
            result[i++] = item;
        }
        return result;
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<>() {
            private Node<T> current = head;

            @Override
            public boolean hasNext() {
                return current != null;
            }

            @Override
            public T next() {
                if (current == null) throw new NoSuchElementException();
                T value = current.value;
                current = current.next;
                return value;
            }
        };
    }
}
