package com.sagana.datastructures;

/**
 * Custom resizable (dynamic) array — a generic data structure that grows its
 * backing storage automatically as elements are added.
 *
 * Backs the Batches list shown in the Dashboard/Farm & Harvest screens
 * (Chapter 1, Section 5.1), giving indexed access to a growing,
 * unpredictable number of batch records without a fixed upper bound.
 *
 * Complexity:
 *  - get/set by index:      O(1)
 *  - add (no resize):       amortized O(1)
 *  - add (triggers resize): O(n) for that call, since every element is copied
 *  - remove/search by value:O(n), since elements must be scanned/shifted
 *
 * @param <T> the type of element stored
 */
public class ResizableArray<T> {

    private static final int DEFAULT_CAPACITY = 4;
    private static final int GROWTH_FACTOR = 2;

    private Object[] elements;
    private int size;      // number of elements actually stored
    private int capacity;  // total allocated slots

    public ResizableArray() {
        this(DEFAULT_CAPACITY);
    }

    public ResizableArray(int initialCapacity) {
        if (initialCapacity <= 0) initialCapacity = DEFAULT_CAPACITY;
        this.capacity = initialCapacity;
        this.elements = new Object[capacity];
        this.size = 0;
    }

    /** Number of elements currently stored (not the same as capacity). */
    public int size() {
        return size;
    }

    /** Total number of slots currently allocated in the backing array. */
    public int capacity() {
        return capacity;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    /** Appends an element to the end of the array, resizing first if needed. */
    public void add(T element) {
        if (size == capacity) {
            resize();
        }
        elements[size] = element;
        size++;
    }

    /** Doubles the backing array's capacity and copies existing elements over. O(n). */
    private void resize() {
        int newCapacity = capacity * GROWTH_FACTOR;
        Object[] newElements = new Object[newCapacity];
        for (int i = 0; i < size; i++) {
            newElements[i] = elements[i];
        }
        elements = newElements;
        capacity = newCapacity;
    }

    @SuppressWarnings("unchecked")
    public T get(int index) {
        checkIndex(index);
        return (T) elements[index];
    }

    public void set(int index, T element) {
        checkIndex(index);
        elements[index] = element;
    }

    /** Removes the element at the given index, shifting later elements left. O(n). */
    @SuppressWarnings("unchecked")
    public T removeAt(int index) {
        checkIndex(index);
        T removed = (T) elements[index];
        for (int i = index; i < size - 1; i++) {
            elements[i] = elements[i + 1];
        }
        elements[size - 1] = null;
        size--;
        return removed;
    }

    /** Removes the first occurrence equal to the given element, if present. O(n). */
    public boolean remove(T element) {
        int index = indexOf(element);
        if (index == -1) return false;
        removeAt(index);
        return true;
    }

    /** Linear search for the index of the first matching element, or -1. O(n). */
    public int indexOf(T element) {
        for (int i = 0; i < size; i++) {
            if (elements[i] == null ? element == null : elements[i].equals(element)) {
                return i;
            }
        }
        return -1;
    }

    public boolean contains(T element) {
        return indexOf(element) != -1;
    }

    private void checkIndex(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index " + index + " out of bounds for size " + size);
        }
    }

    /** Returns a plain Java array snapshot, useful for populating Swing components. */
    @SuppressWarnings("unchecked")
    public T[] toArray(T[] template) {
        T[] result = template.length >= size
                ? template
                : (T[]) java.lang.reflect.Array.newInstance(template.getClass().getComponentType(), size);
        for (int i = 0; i < size; i++) {
            result[i] = (T) elements[i];
        }
        return result;
    }
}
