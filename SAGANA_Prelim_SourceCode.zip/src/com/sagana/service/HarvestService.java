package com.sagana.service;

import com.sagana.datastructures.ResizableArray;
import com.sagana.model.Batch;
import com.sagana.model.FreshnessStatus;
import com.sagana.util.Constants;
import com.sagana.util.IdGenerator;

import java.time.LocalDateTime;

/**
 * Farm and Harvest Management service. Wraps the custom ResizableArray to
 * provide the Create / Read / Update / Delete / Search operations required
 * by the Batches and Batch Details screens (Chapter 1, Required System
 * Functions).
 */
public class HarvestService {

    private final ResizableArray<Batch> batches = new ResizableArray<>(Constants.DEFAULT_BATCH_CAPACITY);

    /** Registers a new harvest as a Batch record. */
    public Batch registerHarvest(String farmName, String cropType, String category,
                                  LocalDateTime harvestDate, double quantityKg, int shelfLifeHours) {
        Batch batch = new Batch(IdGenerator.nextBatchId(), farmName, cropType, category,
                harvestDate, quantityKg, shelfLifeHours);
        batches.add(batch);
        return batch;
    }

    public ResizableArray<Batch> getAllBatches() {
        return batches;
    }

    public int totalBatches() {
        return batches.size();
    }

    /** Linear search for a batch by its ID. O(n). */
    public Batch findById(String batchId) {
        for (int i = 0; i < batches.size(); i++) {
            Batch b = batches.get(i);
            if (b.getBatchId().equalsIgnoreCase(batchId)) {
                return b;
            }
        }
        return null;
    }

    /** Linear search for batches whose crop type contains the given keyword (case-insensitive). O(n). */
    public ResizableArray<Batch> searchByCropType(String keyword) {
        ResizableArray<Batch> results = new ResizableArray<>();
        String lower = keyword.toLowerCase();
        for (int i = 0; i < batches.size(); i++) {
            Batch b = batches.get(i);
            if (b.getCropType().toLowerCase().contains(lower)) {
                results.add(b);
            }
        }
        return results;
    }

    /** Removes a batch by ID. Returns true if a batch was found and removed. */
    public boolean removeBatch(String batchId) {
        Batch batch = findById(batchId);
        if (batch == null) return false;
        return batches.remove(batch);
    }

    /** Counts currently stored batches by freshness status, for the Dashboard's Freshness Overview. */
    public int countByStatus(FreshnessStatus status) {
        int count = 0;
        for (int i = 0; i < batches.size(); i++) {
            if (batches.get(i).computeFreshnessStatus() == status) {
                count++;
            }
        }
        return count;
    }
}
