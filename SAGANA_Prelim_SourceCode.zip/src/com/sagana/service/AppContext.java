package com.sagana.service;

/**
 * Simple shared-instance holder for the Prelim build's services, so every
 * screen operates on the same underlying data structures during a session.
 * A future term may replace this with proper dependency injection.
 */
public final class AppContext {

    public static final HarvestService HARVEST_SERVICE = new HarvestService();
    public static final AlertQueueService ALERT_QUEUE_SERVICE = new AlertQueueService();

    private AppContext() { }
}
