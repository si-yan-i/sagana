package com.sagana.service;

import com.sagana.datastructures.CustomQueue;
import com.sagana.model.Batch;
import com.sagana.model.FreshnessStatus;

/**
 * Near-Spoilage alert pipeline (Prelim stage). Uses the custom FIFO queue to
 * process batches that cross into Near Spoilage status in the exact order
 * they were flagged — later extended into a priority queue (min-heap) in the
 * Final Term, as noted in Chapter 1, Section 5.4.
 */
public class AlertQueueService {

    private final CustomQueue<Batch> alertQueue = new CustomQueue<>();

    /** Flags a batch for alert processing if it is Near Spoilage and not already queued. */
    public boolean flagIfNearSpoilage(Batch batch) {
        if (batch.computeFreshnessStatus() == FreshnessStatus.NEAR_SPOILAGE) {
            alertQueue.enqueue(batch);
            return true;
        }
        return false;
    }

    public boolean hasPendingAlerts() {
        return !alertQueue.isEmpty();
    }

    public int pendingCount() {
        return alertQueue.size();
    }

    /** Previews the next batch to be processed without removing it from the queue. */
    public Batch peekNextAlert() {
        return alertQueue.isEmpty() ? null : alertQueue.peek();
    }

    /** Processes (removes) the next flagged batch from the queue, in flagged order. */
    public Batch processNextAlert() {
        return alertQueue.isEmpty() ? null : alertQueue.dequeue();
    }
}
