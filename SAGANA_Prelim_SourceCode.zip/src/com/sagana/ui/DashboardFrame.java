package com.sagana.ui;

import com.sagana.model.FreshnessStatus;
import com.sagana.service.AppContext;

import javax.swing.*;
import java.awt.*;

/**
 * Main Admin Dashboard. Provides a real-time overview of active batches by
 * freshness status and quick access to the Farm & Harvest and Alerts
 * (Near-Spoilage queue) screens, per the GUI Requirements in Chapter 1.
 *
 * Note: the Key Metrics (Kilograms Rescued, Meals Recovered, Waste Rescued,
 * Transactions) require the Food Rescue Matching feature planned for the
 * Final Term; they are shown here as placeholders reflecting current scope.
 */
public class DashboardFrame extends JFrame {

    private JLabel freshCount, safeCount, nearCount, spoiledCount, totalCount, pendingAlertsLabel;

    public DashboardFrame() {
        setTitle("SAGANA — Admin Dashboard");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(520, 480);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // --- Header ---
        JLabel header = new JLabel("SAGANA Dashboard", SwingConstants.LEFT);
        header.setFont(new Font("SansSerif", Font.BOLD, 20));
        root.add(header, BorderLayout.NORTH);

        // --- Center: Freshness Overview + Key Metrics ---
        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));

        center.add(buildFreshnessOverviewPanel());
        center.add(Box.createVerticalStrut(15));
        center.add(buildKeyMetricsPanel());
        center.add(Box.createVerticalStrut(15));
        center.add(buildQuickAccessPanel());

        root.add(new JScrollPane(center), BorderLayout.CENTER);

        // --- Bottom navigation ---
        JPanel bottomNav = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton dashboardBtn = new JButton("Dashboard");
        dashboardBtn.setEnabled(false);
        JButton notificationsBtn = new JButton("Notifications");
        JButton logoutBtn = new JButton("Logout");

        notificationsBtn.addActionListener(e -> new AlertQueueFrame().setVisible(true));
        logoutBtn.addActionListener(e -> {
            dispose();
            SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
        });

        bottomNav.add(dashboardBtn);
        bottomNav.add(notificationsBtn);
        bottomNav.add(logoutBtn);
        root.add(bottomNav, BorderLayout.SOUTH);

        add(root);
        refreshCounts();
    }

    private JPanel buildFreshnessOverviewPanel() {
        JPanel panel = new JPanel(new GridLayout(0, 2, 8, 4));
        panel.setBorder(BorderFactory.createTitledBorder("Freshness Overview"));

        freshCount = new JLabel();
        safeCount = new JLabel();
        nearCount = new JLabel();
        spoiledCount = new JLabel();
        totalCount = new JLabel();

        panel.add(new JLabel("Fresh:"));
        panel.add(freshCount);
        panel.add(new JLabel("Safe for Sale:"));
        panel.add(safeCount);
        panel.add(new JLabel("Near Spoilage:"));
        panel.add(nearCount);
        panel.add(new JLabel("Spoiled:"));
        panel.add(spoiledCount);
        panel.add(new JLabel("Total Batches:"));
        panel.add(totalCount);

        return panel;
    }

    private JPanel buildKeyMetricsPanel() {
        JPanel panel = new JPanel(new GridLayout(0, 2, 8, 4));
        panel.setBorder(BorderFactory.createTitledBorder("Key Metrics (Final Term feature — preview)"));
        panel.add(new JLabel("Kilograms Rescued:"));
        panel.add(new JLabel("0.0 kg"));
        panel.add(new JLabel("Meals Recovered:"));
        panel.add(new JLabel("0"));
        panel.add(new JLabel("Waste Rescued:"));
        panel.add(new JLabel("0.0%"));
        panel.add(new JLabel("Transactions:"));
        panel.add(new JLabel("0"));

        pendingAlertsLabel = new JLabel();
        panel.add(new JLabel("Pending Near-Spoilage Alerts:"));
        panel.add(pendingAlertsLabel);

        return panel;
    }

    private JPanel buildQuickAccessPanel() {
        JPanel panel = new JPanel(new GridLayout(0, 1, 6, 6));
        panel.setBorder(BorderFactory.createTitledBorder("Quick Access"));

        JButton farmHarvestBtn = new JButton("Farm & Harvest");
        farmHarvestBtn.addActionListener(e -> {
            FarmHarvestFrame frame = new FarmHarvestFrame();
            frame.setVisible(true);
            // Refresh dashboard counts once the Farm & Harvest window closes.
            frame.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosed(java.awt.event.WindowEvent e) {
                    refreshCounts();
                }
            });
        });

        JButton alertsBtn = new JButton("Near-Spoilage Alerts (Queue)");
        alertsBtn.addActionListener(e -> {
            AlertQueueFrame frame = new AlertQueueFrame();
            frame.setVisible(true);
            frame.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosed(java.awt.event.WindowEvent e) {
                    refreshCounts();
                }
            });
        });

        panel.add(farmHarvestBtn);
        panel.add(alertsBtn);
        return panel;
    }

    /** Recomputes and displays the Freshness Overview counts from the ResizableArray of batches. */
    public void refreshCounts() {
        freshCount.setText(String.valueOf(AppContext.HARVEST_SERVICE.countByStatus(FreshnessStatus.FRESH)));
        safeCount.setText(String.valueOf(AppContext.HARVEST_SERVICE.countByStatus(FreshnessStatus.SAFE_FOR_SALE)));
        nearCount.setText(String.valueOf(AppContext.HARVEST_SERVICE.countByStatus(FreshnessStatus.NEAR_SPOILAGE)));
        spoiledCount.setText(String.valueOf(AppContext.HARVEST_SERVICE.countByStatus(FreshnessStatus.SPOILED)));
        totalCount.setText(String.valueOf(AppContext.HARVEST_SERVICE.totalBatches()));
        pendingAlertsLabel.setText(String.valueOf(AppContext.ALERT_QUEUE_SERVICE.pendingCount()));
    }
}
