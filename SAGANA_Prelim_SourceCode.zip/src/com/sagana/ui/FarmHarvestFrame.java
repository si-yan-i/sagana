package com.sagana.ui;

import com.sagana.datastructures.ResizableArray;
import com.sagana.model.Batch;
import com.sagana.service.AppContext;
import com.sagana.util.ValidationUtil;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;

/**
 * Farm & Harvest screen. Lists registered batches (backed by the custom
 * ResizableArray), supports registering new harvests, searching by crop
 * type, removing batches, and opening Batch Details.
 */
public class FarmHarvestFrame extends JFrame {

    private DefaultListModel<Batch> listModel;
    private JList<Batch> batchList;

    public FarmHarvestFrame() {
        setTitle("SAGANA — Farm & Harvest");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(560, 480);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // --- Search bar ---
        JPanel searchPanel = new JPanel(new BorderLayout(6, 6));
        JTextField searchField = new JTextField();
        JButton searchBtn = new JButton("Search");
        JButton clearBtn = new JButton("Clear");
        JPanel searchButtons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchButtons.add(searchBtn);
        searchButtons.add(clearBtn);
        searchPanel.add(new JLabel("Search by crop type:"), BorderLayout.WEST);
        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(searchButtons, BorderLayout.EAST);
        root.add(searchPanel, BorderLayout.NORTH);

        // --- Batch list ---
        listModel = new DefaultListModel<>();
        batchList = new JList<>(listModel);
        batchList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        root.add(new JScrollPane(batchList), BorderLayout.CENTER);

        // --- Action buttons ---
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton addBtn = new JButton("Register Harvest");
        JButton viewBtn = new JButton("View Batch Details");
        JButton removeBtn = new JButton("Remove Batch");
        actions.add(addBtn);
        actions.add(viewBtn);
        actions.add(removeBtn);
        root.add(actions, BorderLayout.SOUTH);

        add(root);
        reloadAllBatches();

        // --- Wiring ---
        searchBtn.addActionListener(e -> {
            String keyword = searchField.getText().trim();
            if (keyword.isEmpty()) {
                reloadAllBatches();
                return;
            }
            listModel.clear();
            ResizableArray<Batch> results = AppContext.HARVEST_SERVICE.searchByCropType(keyword);
            for (int i = 0; i < results.size(); i++) {
                listModel.addElement(results.get(i));
            }
            if (results.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No batches found for \"" + keyword + "\".");
            }
        });

        clearBtn.addActionListener(e -> {
            searchField.setText("");
            reloadAllBatches();
        });

        addBtn.addActionListener(e -> openRegisterHarvestDialog());

        viewBtn.addActionListener(e -> {
            Batch selected = batchList.getSelectedValue();
            if (selected == null) {
                JOptionPane.showMessageDialog(this, "Please select a batch first.");
                return;
            }
            new BatchDetailsFrame(selected).setVisible(true);
        });

        removeBtn.addActionListener(e -> {
            Batch selected = batchList.getSelectedValue();
            if (selected == null) {
                JOptionPane.showMessageDialog(this, "Please select a batch first.");
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Remove batch " + selected.getBatchId() + "?", "Confirm Removal",
                    JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                AppContext.HARVEST_SERVICE.removeBatch(selected.getBatchId());
                reloadAllBatches();
            }
        });
    }

    private void reloadAllBatches() {
        listModel.clear();
        ResizableArray<Batch> all = AppContext.HARVEST_SERVICE.getAllBatches();
        for (int i = 0; i < all.size(); i++) {
            listModel.addElement(all.get(i));
        }
    }

    private void openRegisterHarvestDialog() {
        JTextField farmField = new JTextField();
        JTextField cropField = new JTextField();
        String[] categories = {"Vegetable", "Fruit", "Grain"};
        JComboBox<String> categoryBox = new JComboBox<>(categories);
        JTextField quantityField = new JTextField();
        JTextField shelfLifeField = new JTextField();

        JPanel form = new JPanel(new GridLayout(0, 2, 6, 6));
        form.add(new JLabel("Farm name:"));
        form.add(farmField);
        form.add(new JLabel("Crop type:"));
        form.add(cropField);
        form.add(new JLabel("Category:"));
        form.add(categoryBox);
        form.add(new JLabel("Quantity (kg):"));
        form.add(quantityField);
        form.add(new JLabel("Shelf life (hours):"));
        form.add(shelfLifeField);

        int result = JOptionPane.showConfirmDialog(this, form, "Register Harvest",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION) return;

        if (ValidationUtil.isBlank(farmField.getText()) || ValidationUtil.isBlank(cropField.getText())
                || !ValidationUtil.isPositiveNumber(quantityField.getText())
                || !ValidationUtil.isPositiveInteger(shelfLifeField.getText())) {
            JOptionPane.showMessageDialog(this,
                    "Please fill in all fields correctly (quantity and shelf life must be positive numbers).",
                    "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return;
        }

        AppContext.HARVEST_SERVICE.registerHarvest(
                farmField.getText().trim(),
                cropField.getText().trim(),
                (String) categoryBox.getSelectedItem(),
                LocalDateTime.now(),
                Double.parseDouble(quantityField.getText().trim()),
                Integer.parseInt(shelfLifeField.getText().trim())
        );

        JOptionPane.showMessageDialog(this, "Harvest registered successfully.");
        reloadAllBatches();
    }
}
