package com.sagana.ui;

import com.sagana.model.Batch;
import com.sagana.service.AppContext;

import javax.swing.*;
import java.awt.*;

/**
 * Near-Spoilage Alerts screen (Prelim scope: queue demonstration only). Shows
 * how many batches are currently queued for alert processing and lets the
 * admin process them one at a time, strictly in the order they were flagged
 * — demonstrating the custom FIFO queue described in Chapter 1, Section 5.4.
 *
 * The full Near-Spoilage Recovery screen (organization matching, pickup
 * requests) is a Midterm Term feature per the Initial Semester Plan.
 */
public class AlertQueueFrame extends JFrame {

    private JLabel pendingLabel;
    private JLabel nextAlertLabel;
    private DefaultListModel<String> processedModel;

    public AlertQueueFrame() {
        setTitle("SAGANA — Near-Spoilage Alerts (Queue)");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(460, 420);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel infoPanel = new JPanel(new GridLayout(0, 1, 4, 4));
        infoPanel.setBorder(BorderFactory.createTitledBorder("Alert Queue Status"));
        pendingLabel = new JLabel();
        nextAlertLabel = new JLabel();
        infoPanel.add(pendingLabel);
        infoPanel.add(nextAlertLabel);
        root.add(infoPanel, BorderLayout.NORTH);

        processedModel = new DefaultListModel<>();
        JList<String> processedList = new JList<>(processedModel);
        JPanel processedPanel = new JPanel(new BorderLayout());
        processedPanel.setBorder(BorderFactory.createTitledBorder("Processed This Session (FIFO order)"));
        processedPanel.add(new JScrollPane(processedList), BorderLayout.CENTER);
        root.add(processedPanel, BorderLayout.CENTER);

        JButton processBtn = new JButton("Process Next Alert");
        processBtn.addActionListener(e -> {
            Batch processed = AppContext.ALERT_QUEUE_SERVICE.processNextAlert();
            if (processed == null) {
                JOptionPane.showMessageDialog(this, "No pending alerts to process.");
            } else {
                processedModel.addElement(processed.getBatchId() + " — " + processed.getCropType()
                        + " (from " + processed.getFarmName() + ")");
            }
            refresh();
        });

        JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        southPanel.add(processBtn);
        root.add(southPanel, BorderLayout.SOUTH);

        add(root);
        refresh();
    }

    private void refresh() {
        pendingLabel.setText("Pending alerts in queue: " + AppContext.ALERT_QUEUE_SERVICE.pendingCount());
        Batch next = AppContext.ALERT_QUEUE_SERVICE.peekNextAlert();
        nextAlertLabel.setText("Next in line: " + (next == null ? "None" : next.getBatchId() + " (" + next.getCropType() + ")"));
    }
}
