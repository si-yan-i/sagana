package com.sagana.ui;

import com.sagana.model.Batch;
import com.sagana.model.BatchEvent;
import com.sagana.model.EventType;
import com.sagana.model.FreshnessStatus;
import com.sagana.service.AppContext;

import javax.swing.*;
import java.awt.*;

/**
 * Batch Details screen. Displays a single batch's information and its
 * continuously updated freshness timeline, built by traversing the batch's
 * SinglyLinkedList event history in chronological (append) order.
 */
public class BatchDetailsFrame extends JFrame {

    private final Batch batch;
    private JLabel statusLabel;
    private DefaultListModel<String> timelineModel;

    public BatchDetailsFrame(Batch batch) {
        this.batch = batch;

        setTitle("SAGANA — Batch Details: " + batch.getBatchId());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(480, 500);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        root.add(buildInfoPanel(), BorderLayout.NORTH);

        timelineModel = new DefaultListModel<>();
        JList<String> timelineList = new JList<>(timelineModel);
        JPanel timelinePanel = new JPanel(new BorderLayout());
        timelinePanel.setBorder(BorderFactory.createTitledBorder("Freshness Timeline (Event History)"));
        timelinePanel.add(new JScrollPane(timelineList), BorderLayout.CENTER);
        root.add(timelinePanel, BorderLayout.CENTER);

        root.add(buildActionsPanel(), BorderLayout.SOUTH);

        add(root);
        refresh();
    }

    private JPanel buildInfoPanel() {
        JPanel panel = new JPanel(new GridLayout(0, 2, 6, 4));
        panel.setBorder(BorderFactory.createTitledBorder("Batch Information"));

        panel.add(new JLabel("Batch ID:"));
        panel.add(new JLabel(batch.getBatchId()));
        panel.add(new JLabel("Farm:"));
        panel.add(new JLabel(batch.getFarmName()));
        panel.add(new JLabel("Crop / Category:"));
        panel.add(new JLabel(batch.getCropType() + " / " + batch.getCategory()));
        panel.add(new JLabel("Quantity:"));
        panel.add(new JLabel(batch.getQuantityKg() + " kg"));
        panel.add(new JLabel("Shelf Life:"));
        panel.add(new JLabel(batch.getShelfLifeHours() + " hours"));

        statusLabel = new JLabel();
        panel.add(new JLabel("Freshness Status:"));
        panel.add(statusLabel);

        return panel;
    }

    private JPanel buildActionsPanel() {
        JPanel panel = new JPanel(new GridLayout(0, 1, 6, 6));

        JPanel eventButtons = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton dispatchBtn = new JButton("Log Dispatched");
        JButton delayBtn = new JButton("Log Delayed");
        JButton arriveBtn = new JButton("Log Arrived");
        eventButtons.add(dispatchBtn);
        eventButtons.add(delayBtn);
        eventButtons.add(arriveBtn);

        dispatchBtn.addActionListener(e -> logEvent(EventType.DISPATCHED, "Batch dispatched for delivery"));
        delayBtn.addActionListener(e -> logEvent(EventType.DELAYED, "Delay reported in transit"));
        arriveBtn.addActionListener(e -> logEvent(EventType.ARRIVED, "Batch arrived at destination"));

        JButton checkAlertBtn = new JButton("Recheck Freshness / Flag Alert");
        checkAlertBtn.addActionListener(e -> {
            refresh();
            boolean flagged = AppContext.ALERT_QUEUE_SERVICE.flagIfNearSpoilage(batch);
            if (flagged) {
                JOptionPane.showMessageDialog(this,
                        "Batch " + batch.getBatchId() + " is Near Spoilage and has been queued for alert processing.");
            } else if (batch.computeFreshnessStatus() == FreshnessStatus.SPOILED) {
                JOptionPane.showMessageDialog(this,
                        "Batch " + batch.getBatchId() + " is already Spoiled.");
            } else {
                JOptionPane.showMessageDialog(this,
                        "Batch " + batch.getBatchId() + " is not yet Near Spoilage.");
            }
        });

        panel.add(eventButtons);
        panel.add(checkAlertBtn);
        return panel;
    }

    private void logEvent(EventType type, String note) {
        batch.logEvent(type, note);
        refresh();
    }

    /** Rebuilds the status label and timeline list by traversing the batch's linked list. */
    private void refresh() {
        statusLabel.setText(batch.computeFreshnessStatus().toString());

        timelineModel.clear();
        // Traversal of the SinglyLinkedList — O(n) — in the order events were appended.
        for (BatchEvent event : batch.getEventHistory()) {
            timelineModel.addElement(event.toString());
        }
    }
}
