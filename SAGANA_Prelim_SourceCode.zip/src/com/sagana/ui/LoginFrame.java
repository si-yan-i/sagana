package com.sagana.ui;

import com.sagana.util.Constants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * Login screen. Authenticates the admin before any batch or system data can
 * be accessed, per the Prelim Term's Login/Logout requirement.
 */
public class LoginFrame extends JFrame {

    public LoginFrame() {
        setTitle("SAGANA — Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(360, 260);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("SAGANA", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 22));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(title, gbc);

        JLabel subtitle = new JLabel("Admin Login", SwingConstants.CENTER);
        gbc.gridy = 1;
        panel.add(subtitle, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 2; gbc.gridx = 0;
        panel.add(new JLabel("Username:"), gbc);
        JTextField usernameField = new JTextField(14);
        gbc.gridx = 1;
        panel.add(usernameField, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("Password:"), gbc);
        JPasswordField passwordField = new JPasswordField(14);
        gbc.gridx = 1;
        panel.add(passwordField, gbc);

        JLabel statusLabel = new JLabel(" ");
        statusLabel.setForeground(Color.RED);
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        panel.add(statusLabel, gbc);

        JButton loginButton = new JButton("Log In");
        gbc.gridy = 5;
        panel.add(loginButton, gbc);

        loginButton.addActionListener((ActionEvent e) -> {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());

            if (username.equals(Constants.ADMIN_USERNAME) && password.equals(Constants.ADMIN_PASSWORD)) {
                dispose();
                SwingUtilities.invokeLater(() -> new DashboardFrame().setVisible(true));
            } else {
                statusLabel.setText("Invalid username or password.");
                passwordField.setText("");
            }
        });

        // Allow pressing Enter in the password field to submit.
        passwordField.addActionListener(e -> loginButton.doClick());

        add(panel);
    }
}
