package com.sagana;

import com.sagana.ui.LoginFrame;

import javax.swing.*;

/**
 * Entry point for the SAGANA Prelim application. Launches the Login screen;
 * default admin credentials are defined in com.sagana.util.Constants.
 */
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
