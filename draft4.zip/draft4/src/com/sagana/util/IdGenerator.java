package com.sagana.util;

/**
 * Generates simple, sequential, human-readable batch IDs (e.g. B0001, B0002).
 *
 * Note: RouteNode and RouteEdge IDs are NOT generated here — RoutingService
 * generates those by scanning its own live node/edge list for the lowest
 * free number, so a deleted location's ID (e.g. N002) gets reused by the
 * next new location instead of IDs climbing forever. Batches are different:
 * once a batch is harvested, deleting old batches isn't a normal workflow
 * the way deleting a test location is, so a simple ever-increasing counter
 * is the right fit here.
 */
public final class IdGenerator {

    private static int counter = 0;

    private IdGenerator() { }

    public static synchronized String nextBatchId() {
        counter++;
        return Constants.BATCH_ID_PREFIX + String.format("%04d", counter);
    }

    // --- Persistence support: the counter must be saved and restored
    // alongside the data itself, or batch IDs generated after a reload
    // could collide with IDs already assigned to loaded batches.

    public static synchronized int currentBatchCounter() { return counter; }

    public static synchronized void restoreCounters(int batchCounter) {
        counter = batchCounter;
    }
}
