package com.sagana.model;

import java.io.Serializable;

/**
 * A route between two RouteNodes, weighted by distance and expected travel
 * time. RoutingService derives the actual Dijkstra edge cost from these base
 * figures combined with a batch's remaining shelf life.
 */
public class RouteEdge implements Serializable {

    private static final long serialVersionUID = 1L;

    private final String edgeId;
    private final String fromNodeId;
    private final String toNodeId;
    private final double distanceKm;
    private final double baseTravelHours;

    public RouteEdge(String edgeId, String fromNodeId, String toNodeId,
                      double distanceKm, double baseTravelHours) {
        this.edgeId = edgeId;
        this.fromNodeId = fromNodeId;
        this.toNodeId = toNodeId;
        this.distanceKm = distanceKm;
        this.baseTravelHours = baseTravelHours;
    }

    public String getEdgeId() { return edgeId; }
    public String getFromNodeId() { return fromNodeId; }
    public String getToNodeId() { return toNodeId; }
    public double getDistanceKm() { return distanceKm; }
    public double getBaseTravelHours() { return baseTravelHours; }

    @Override
    public String toString() {
        return String.format("[%s] %s -> %s (%.1f km, %.1f hrs)",
                edgeId, fromNodeId, toNodeId, distanceKm, baseTravelHours);
    }
}
