package com.sagana.model;

/**
 * Types of locations in the delivery route network. FARM and MARKET are
 * real destinations. WAYPOINT is not a destination at all — it represents a
 * bend, intersection, or landmark along a real road, used to break one long
 * direct edge into several shorter, directional segments (e.g. Farm ->
 * Junction A -> Junction B -> Market instead of one straight line).
 */
public enum NodeType {
    FARM,
    MARKET,
    WAYPOINT
}
