package com.sagana.model;

import java.io.Serializable;

/**
 * A single location in the delivery route network (a farm or market). Nodes
 * and the RouteEdges connecting them form the graph that RoutingService runs
 * Dijkstra's algorithm over (Chapter 1, Midterm scope — Route Planning/
 * Delivery Monitoring).
 */
public class RouteNode implements Serializable {

    private static final long serialVersionUID = 1L;

    private final String nodeId;
    private final String name;
    private final NodeType type;
    private final double lat;
    private final double lng;

    public RouteNode(String nodeId, String name, NodeType type, double lat, double lng) {
        this.nodeId = nodeId;
        this.name = name;
        this.type = type;
        this.lat = lat;
        this.lng = lng;
    }

    public String getNodeId() { return nodeId; }
    public String getName() { return name; }
    public NodeType getType() { return type; }
    public double getLat() { return lat; }
    public double getLng() { return lng; }

    @Override
    public String toString() {
        return String.format("[%s] %s (%s)", nodeId, name, type);
    }
}
