package com.sagana.ui;

import com.sagana.datastructures.ResizableArray;
import com.sagana.model.NodeType;
import com.sagana.model.RouteEdge;
import com.sagana.model.RouteNode;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Lightweight schematic visualization of the route network. Not a real
 * street/satellite map — it plots each RouteNode's stored lat/lng, scaled to
 * fit the panel, and draws RouteEdges as lines between them. This gives the
 * route network a visual layout without needing an internet connection,
 * an API key, or a mapping library.
 *
 * The most recently computed Dijkstra path can be highlighted in red via
 * setHighlightedPath, so the recommended route is visible at a glance.
 */
public class RouteMapPanel extends JPanel {

    private static final int PADDING = 50;
    private static final int NODE_RADIUS = 10;
    private static final int WAYPOINT_RADIUS = 4;
    private static final int BASE_WIDTH = 600;
    private static final int BASE_HEIGHT = 480;
    private static final double MIN_ZOOM = 0.5;
    private static final double MAX_ZOOM = 3.0;
    private static final double ZOOM_STEP = 1.25;

    private ResizableArray<RouteNode> nodes;
    private ResizableArray<RouteEdge> edges;
    private List<String> highlightedPath; // node IDs in path order, or null
    private double zoomLevel = 1.0;

    public RouteMapPanel(ResizableArray<RouteNode> nodes, ResizableArray<RouteEdge> edges) {
        this.nodes = nodes;
        this.edges = edges;
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(BASE_WIDTH, BASE_HEIGHT));
    }

    // ---------- Zoom: expands the panel itself, which forces computePositions()
    // to spread nodes further apart on the next repaint, since it always scales
    // from the panel's actual current size. Node radius/label size stay fixed
    // on purpose, so zooming in gives more breathing room between nodes without
    // making everything look oversized — zoom spaces things out, it doesn't
    // magnify them. The surrounding JScrollPane (added in RoutePlanningFrame)
    // is what lets the panel grow beyond the visible area and still be
    // scrolled to, instead of being squeezed back down to fit.

    public void zoomIn() {
        zoomLevel = Math.min(MAX_ZOOM, zoomLevel * ZOOM_STEP);
        applyZoom();
    }

    public void zoomOut() {
        zoomLevel = Math.max(MIN_ZOOM, zoomLevel / ZOOM_STEP);
        applyZoom();
    }

    public void resetZoom() {
        zoomLevel = 1.0;
        applyZoom();
    }

    public double getZoomLevel() {
        return zoomLevel;
    }

    private void applyZoom() {
        int width = (int) (BASE_WIDTH * zoomLevel);
        int height = (int) (BASE_HEIGHT * zoomLevel);
        setPreferredSize(new Dimension(width, height));
        revalidate(); // tells the enclosing JScrollPane the content size changed
        repaint();
    }

    /** Highlights the given path (node IDs in order) in red, or clears it if null. */
    public void setHighlightedPath(List<String> path) {
        this.highlightedPath = path;
        repaint();
    }

    /** Call after nodes/edges change elsewhere, so the map reflects the latest network. */
    public void refreshData(ResizableArray<RouteNode> nodes, ResizableArray<RouteEdge> edges) {
        this.nodes = nodes;
        this.edges = edges;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (nodes == null || nodes.isEmpty()) {
            g2.setColor(Color.GRAY);
            g2.drawString("No locations registered yet. Add locations to see the map.", 20, 30);
            return;
        }

        Map<String, Point> positions = computePositions();
        Set<String> highlightEdgeKeys = highlightedEdgeKeys();

        // Edges drawn first so node circles and labels sit visually on top.
        for (int i = 0; i < edges.size(); i++) {
            RouteEdge edge = edges.get(i);
            Point from = positions.get(edge.getFromNodeId());
            Point to = positions.get(edge.getToNodeId());
            if (from == null || to == null) continue;

            boolean isHighlighted = highlightEdgeKeys.contains(edgeKey(edge.getFromNodeId(), edge.getToNodeId()));
            g2.setStroke(new BasicStroke(isHighlighted ? 3.5f : 1.5f));
            g2.setColor(isHighlighted ? new Color(214, 40, 40) : new Color(180, 180, 180));
            g2.drawLine(from.x, from.y, to.x, to.y);

            int midX = (from.x + to.x) / 2;
            int midY = (from.y + to.y) / 2;
            g2.setFont(g2.getFont().deriveFont(11f));
            g2.setColor(Color.DARK_GRAY);
            g2.drawString(String.format("%.1f km / %.1f h", edge.getDistanceKm(), edge.getBaseTravelHours()), midX, midY);
        }

        // Nodes drawn on top of edges.
        for (int i = 0; i < nodes.size(); i++) {
            RouteNode node = nodes.get(i);
            Point p = positions.get(node.getNodeId());
            if (p == null) continue;

            boolean onPath = highlightedPath != null && highlightedPath.contains(node.getNodeId());
            boolean isWaypoint = node.getType() == NodeType.WAYPOINT;
            int radius = isWaypoint ? WAYPOINT_RADIUS : NODE_RADIUS;

            Color fill = node.getType() == NodeType.FARM ? new Color(76, 175, 80)
                    : node.getType() == NodeType.MARKET ? new Color(33, 150, 243)
                    : new Color(150, 150, 150); // waypoint: neutral gray
            if (onPath) fill = new Color(214, 40, 40);

            g2.setColor(fill);
            g2.fillOval(p.x - radius, p.y - radius, radius * 2, radius * 2);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(1f));
            g2.drawOval(p.x - radius, p.y - radius, radius * 2, radius * 2);

            // Waypoints stay unlabeled on the map unless they're part of the highlighted
            // route, so real destinations (farms/markets) aren't crowded out visually.
            if (!isWaypoint || onPath) {
                g2.setFont(g2.getFont().deriveFont(isWaypoint ? Font.PLAIN : Font.BOLD, isWaypoint ? 10f : 12f));
                g2.setColor(Color.BLACK);
                g2.drawString(node.getName() + (isWaypoint ? "" : " (" + node.getType() + ")"),
                        p.x + radius + 4, p.y + 4);
            }
        }

        // Direction arrows along the highlighted route, so it reads as a directional
        // path (like turn-by-turn road segments) rather than an undirected line.
        if (highlightedPath != null) {
            for (int i = 0; i < highlightedPath.size() - 1; i++) {
                Point from = positions.get(highlightedPath.get(i));
                Point to = positions.get(highlightedPath.get(i + 1));
                if (from != null && to != null) drawDirectionArrow(g2, from, to);
            }
        }
    }

    /** Draws a small filled triangle at the midpoint of a segment, pointing from 'from' toward 'to'. */
    private void drawDirectionArrow(Graphics2D g2, Point from, Point to) {
        double angle = Math.atan2(to.y - from.y, to.x - from.x);
        int midX = (from.x + to.x) / 2;
        int midY = (from.y + to.y) / 2;
        int arrowLength = 12;

        int tipX = (int) (midX + (arrowLength / 2.0) * Math.cos(angle));
        int tipY = (int) (midY + (arrowLength / 2.0) * Math.sin(angle));
        int x1 = (int) (midX - (arrowLength / 2.0) * Math.cos(angle) - arrowLength * Math.sin(angle) * 0.4);
        int y1 = (int) (midY - (arrowLength / 2.0) * Math.sin(angle) + arrowLength * Math.cos(angle) * 0.4);
        int x2 = (int) (midX - (arrowLength / 2.0) * Math.cos(angle) + arrowLength * Math.sin(angle) * 0.4);
        int y2 = (int) (midY - (arrowLength / 2.0) * Math.sin(angle) - arrowLength * Math.cos(angle) * 0.4);

        Polygon arrowHead = new Polygon();
        arrowHead.addPoint(tipX, tipY);
        arrowHead.addPoint(x1, y1);
        arrowHead.addPoint(x2, y2);
        g2.setColor(new Color(140, 20, 20));
        g2.fillPolygon(arrowHead);
    }

    /**
     * Scales each node's lat/lng into panel pixel coordinates. Longitude maps
     * to x directly; latitude maps to y inverted, since latitude increases
     * northward but screen y increases downward.
     */
    private Map<String, Point> computePositions() {
        double minLat = Double.MAX_VALUE, maxLat = -Double.MAX_VALUE;
        double minLng = Double.MAX_VALUE, maxLng = -Double.MAX_VALUE;

        for (int i = 0; i < nodes.size(); i++) {
            RouteNode n = nodes.get(i);
            minLat = Math.min(minLat, n.getLat());
            maxLat = Math.max(maxLat, n.getLat());
            minLng = Math.min(minLng, n.getLng());
            maxLng = Math.max(maxLng, n.getLng());
        }

        // Uses the panel's actual current size so positions reflect the current
        // zoom level; falls back to the zoomed base size before the panel has
        // been laid out for the first time (getWidth()/getHeight() still 0).
        int width = getWidth() > 0 ? getWidth() : (int) (BASE_WIDTH * zoomLevel);
        int height = getHeight() > 0 ? getHeight() : (int) (BASE_HEIGHT * zoomLevel);

        double latRange = (maxLat - minLat == 0) ? 1 : maxLat - minLat;
        double lngRange = (maxLng - minLng == 0) ? 1 : maxLng - minLng;

        Map<String, Point> positions = new HashMap<>();
        for (int i = 0; i < nodes.size(); i++) {
            RouteNode n = nodes.get(i);
            int x = PADDING + (int) (((n.getLng() - minLng) / lngRange) * (width - 2 * PADDING));
            int y = PADDING + (int) (((maxLat - n.getLat()) / latRange) * (height - 2 * PADDING));
            positions.put(n.getNodeId(), new Point(x, y));
        }
        return positions;
    }

    private Set<String> highlightedEdgeKeys() {
        Set<String> keys = new HashSet<>();
        if (highlightedPath == null) return keys;
        for (int i = 0; i < highlightedPath.size() - 1; i++) {
            keys.add(edgeKey(highlightedPath.get(i), highlightedPath.get(i + 1)));
        }
        return keys;
    }

    /** Undirected edge key so a route drawn either direction still matches for highlighting. */
    private String edgeKey(String a, String b) {
        return a.compareTo(b) < 0 ? a + "|" + b : b + "|" + a;
    }
}