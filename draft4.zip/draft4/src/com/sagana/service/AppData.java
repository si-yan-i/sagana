package com.sagana.service;

import com.sagana.datastructures.CustomQueue;
import com.sagana.datastructures.ResizableArray;
import com.sagana.model.Batch;
import com.sagana.model.RouteEdge;
import com.sagana.model.RouteNode;

import java.io.Serializable;

/**
 * Plain data-transfer snapshot of the application's in-memory state, written
 * to and read from disk as a single unit by PersistenceService. Kept
 * intentionally dumb (no behavior) — it exists purely so one
 * ObjectOutputStream call can save everything at once.
 */
class AppData implements Serializable {

    private static final long serialVersionUID = 1L;

    ResizableArray<Batch> batches;
    CustomQueue<Batch> alertQueue;
    ResizableArray<RouteNode> nodes;
    ResizableArray<RouteEdge> edges;
    int batchCounter;
}
