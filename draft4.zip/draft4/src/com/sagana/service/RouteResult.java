package com.sagana.service;

import java.util.List;

/** Outcome of a RoutingService route computation for one batch. */
public class RouteResult {

    public enum Action { CONTINUE_TO_MARKET, UNREACHABLE }

    private final Action action;
    private final String destinationNodeId;
    private final double totalCost;
    private final List<String> path;

    public RouteResult(Action action, String destinationNodeId, double totalCost, List<String> path) {
        this.action = action;
        this.destinationNodeId = destinationNodeId;
        this.totalCost = totalCost;
        this.path = path;
    }

    public Action getAction() { return action; }
    public String getDestinationNodeId() { return destinationNodeId; }
    public double getTotalCost() { return totalCost; }
    public List<String> getPath() { return path; }
}
