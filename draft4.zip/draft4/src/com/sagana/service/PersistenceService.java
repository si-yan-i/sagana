package com.sagana.service;

import java.io.*;

/**
 * Saves and restores all of SAGANA's in-memory data (batches, alert queue,
 * route network, and ID counters) to a single local file, so data entered
 * under the admin account survives closing and reopening the app.
 *
 * There is one shared admin account (see Constants), so one save file for
 * the whole application is sufficient for this term's scope — a
 * multi-account version would key this file per user instead.
 */
public class PersistenceService {

    private static final String SAVE_FILE = "sagana_data.ser";

    /** Writes the current in-memory state to disk. Called automatically on app exit. */
    public void save() {
        AppData data = new AppData();
        data.batches = AppContext.HARVEST_SERVICE.getAllBatches();
        data.alertQueue = AppContext.ALERT_QUEUE_SERVICE.getQueueForPersistence();
        data.nodes = AppContext.ROUTING_SERVICE.getAllNodes();
        data.edges = AppContext.ROUTING_SERVICE.getAllEdges();
        data.batchCounter = com.sagana.util.IdGenerator.currentBatchCounter();

        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(SAVE_FILE))) {
            out.writeObject(data);
        } catch (IOException e) {
            System.err.println("SAGANA: failed to save data — " + e.getMessage());
        }
    }

    /**
     * Reads saved state from disk, if a save file exists, and restores it into
     * the shared services. Returns true if data was found and loaded.
     * Called once at startup, before the Login screen appears.
     */
    public boolean load() {
        File file = new File(SAVE_FILE);
        if (!file.exists()) return false;

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            AppData data = (AppData) in.readObject();
            AppContext.HARVEST_SERVICE.restoreBatches(data.batches);
            AppContext.ALERT_QUEUE_SERVICE.restoreQueue(data.alertQueue);
            AppContext.ROUTING_SERVICE.restoreNetwork(data.nodes, data.edges);
            com.sagana.util.IdGenerator.restoreCounters(data.batchCounter);
            return true;
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("SAGANA: failed to load saved data — " + e.getMessage());
            return false;
        }
    }
}
