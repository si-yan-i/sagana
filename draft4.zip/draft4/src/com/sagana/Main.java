package com.sagana;

import com.sagana.service.AppContext;
import com.sagana.ui.LoginFrame;

import javax.swing.*;

/**
 * Entry point for the SAGANA application. Restores previously saved data (if
 * any) before the Login screen appears, and registers a shutdown hook so
 * data is written back to disk automatically whenever the app closes —
 * normal window close, Logout-then-close, or System.exit — so nothing needs
 * to be saved manually. Default admin credentials are defined in
 * com.sagana.util.Constants.
 */
public class Main {
    public static void main(String[] args) {
        AppContext.PERSISTENCE_SERVICE.load();

        Runtime.getRuntime().addShutdownHook(new Thread(() -> AppContext.PERSISTENCE_SERVICE.save()));

        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
